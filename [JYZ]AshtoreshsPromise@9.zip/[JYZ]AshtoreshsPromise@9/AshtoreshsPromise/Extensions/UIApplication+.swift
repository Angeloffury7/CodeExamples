//
//  UIApplication+.swift
//  YBTour
//
//  Created by FOCUSONE Inc. on 2023/11/28.
//

import UIKit

extension UIApplication {
    var appDelegate: AppDelegate? {
        return UIApplication.shared.delegate as? AppDelegate
    }
    var sceneDelegate: SceneDelegate? {
        return UIApplication.shared.connectedScenes.first?.delegate as? SceneDelegate
    }
    var rootViewController: UIViewController {
        guard let rootViewController = sceneDelegate?.window?.rootViewController else {
            fatalError("Unable to find root view controller")
        }
        return rootViewController
    }
}
