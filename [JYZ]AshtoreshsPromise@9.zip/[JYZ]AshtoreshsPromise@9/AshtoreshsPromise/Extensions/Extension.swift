//
//  Extension.swift
//  Chat
//
//  Created by haniln on 2022/01/18.
//

import Foundation
import AVFoundation
import UIKit



//MARK: - UINavigationController ---------------------------------
class BaseNavigationController: UINavigationController {
    private var duringTransition = false
    //private var disabledPopVCs = [MainViewController.self, LoginViewController.self]
    override func viewDidLoad() {
        super.viewDidLoad()
        
        interactivePopGestureRecognizer?.delegate = self
        self.delegate = self
    }
    
    override func pushViewController(_ viewController: UIViewController, animated: Bool) {
        duringTransition = true
        
        super.pushViewController(viewController, animated: animated)
    }
}
extension BaseNavigationController: UINavigationControllerDelegate {
    func navigationController(_ navigationController: UINavigationController, didShow viewController: UIViewController, animated: Bool) {
        self.duringTransition = false
    }
}
extension BaseNavigationController: UIGestureRecognizerDelegate {
    func gestureRecognizerShouldBegin(_ gestureRecognizer: UIGestureRecognizer) -> Bool {
        guard gestureRecognizer == interactivePopGestureRecognizer,
              let topVC = topViewController else {
                  return true // default value
              }
        
        return viewControllers.count > 1 && duringTransition == false && isPopGestureEnable(topVC)
    }
    
    private func isPopGestureEnable(_ topVC: UIViewController) -> Bool {
        //for vc in disabledPopVCs {
        //    if String(describing: type(of: topVC)) == String(describing: vc) {
        //        return false
        //    }
        //}
        return true
    }
}

//MARK: - UIViewController ---------------------------------------
extension UIViewController: Storyboarded {}
extension UIViewController {
    public func showToastMessage(_ message: String) {
        let isNotchiPhone:Double = UserDefaults.standard.double(forKey: "isNotchiPhone")
        let window = UIApplication.shared.windows.first!
        let toastLabel = UILabel(frame: CGRect(x: 16, y: window.frame.height - 60 - CGFloat(isNotchiPhone), width: window.frame.width - 32, height: 40))
        let innerLb = UILabel(frame: CGRect(x: 16, y: 0, width: toastLabel.frame.size.width - 16, height: 40))
        
        toastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.7)
        toastLabel.layer.cornerRadius = 4
        toastLabel.clipsToBounds = true
        innerLb.backgroundColor = .clear
        innerLb.textColor = UIColor.white
        innerLb.numberOfLines = 1
        innerLb.font = UIFont(name: "Pretendard-Regular", size: 14)
        innerLb.text = message
        innerLb.textAlignment = .left
        
        if #available(iOS 13.0, *) {
            let keyWindow = UIApplication.shared.windows.first{$0.isKeyWindow}
            guard let window = keyWindow else { return }
            guard let topController = window.rootViewController else { return }
            toastLabel.addSubview(innerLb)
            topController.view.addSubview(toastLabel)
        } else {
            guard let topController = UIApplication.shared.keyWindow?.rootViewController else { return }
            toastLabel.addSubview(innerLb)
            topController.view.addSubview(toastLabel)
        }
        
        UIView.animate(withDuration: 3, delay: 2, options: .curveEaseOut) {
            toastLabel.alpha = 0.0
        } completion: { _ in
            toastLabel.removeFromSuperview()
        }
    }
}


//MARK: - Array -------------------------------------------
extension Array {
    mutating func appendAll(data: [Element], index: Int = -1) {
        if index < 0 { ///배열 데이터 추가
            for emnt in data {
                self.append(emnt)
            }
        } else { ///중간삽입
            for i in 0...data.count-1 {
                self.insert(data[i], at: index+i)
            }
        }
    }
    func lastIndex() -> Int { ///Count-1(대체)
        return self.count-1
    }
}


//MARK: - Storyboarded -------------------------------------------
protocol Storyboarded {
    static func instantiate() -> Self
}
extension Storyboarded where Self:UIViewController {
    static func instantiate() -> Self {
        let id = String(describing: self)
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        return storyboard.instantiateViewController(withIdentifier: id) as! Self
    }
}

//MARK: - UIScrollView ------------------------------------------
extension UIScrollView {
    public func updateContentSize() -> CGFloat { ///-> CGSize {
        let unionCalculatedTotalRect = recursiveUnionInDepthFor(view: self)
        return unionCalculatedTotalRect.height
    }
    private func recursiveUnionInDepthFor(view: UIView) -> CGRect {
        var totalRect: CGRect = .zero
        for subView in view.subviews {
            totalRect = totalRect.union(recursiveUnionInDepthFor(view: subView))
        }
        return totalRect.union(view.frame)
    }
}

//MARK: - UIColor -----------------------------------------------
extension UIColor {
    convenience init(red: Int, green: Int, blue: Int, alpha: CGFloat) {
        self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: alpha)
    }
    //MARK: TabMan
    class var tammanWhite: UIColor {
        UIColor.white
    }
    class var tabmanPrimary: UIColor {
        UIColor(red: 0.56, green: 0.18, blue: 0.89, alpha: 1.00)
    }
    class var tabmanSecondary: UIColor {
        UIColor(red: 0.29, green: 0.00, blue: 0.88, alpha: 1.00)
    }
    class var tabmanForeground: UIColor {
        if #available(iOS 13, *) {
            return UIColor { (traitCollection) -> UIColor in
                switch traitCollection.userInterfaceStyle {
                case .dark:
                    return .white
                default:
                    return UIColor(red: 0.56, green: 0.18, blue: 0.89, alpha: 1.00)
                }
            }
        } else {
            return UIColor(red: 0.56, green: 0.18, blue: 0.89, alpha: 1.00)
        }
    }
}



//MARK: - UILabel -----------------------------------------------
extension UILabel {
    
    func setShowAiAnswerLabel(labelString: String) {
        //MARK: 라벨 화살표 그려줌(개별 오브젝트 방식에서 변경함)
        let imageAttachment = NSTextAttachment()
        imageAttachment.image = UIImage(named:"arw_r_gray")
        imageAttachment.image?.withTintColor(UIColor(red: 33, green: 129, blue: 241, alpha: 1.0))
        // Set bound to reposition
        let imageOffsetY: CGFloat = -3
        imageAttachment.bounds = CGRect(x: 0, y: imageOffsetY, width: imageAttachment.image!.size.width, height: imageAttachment.image!.size.height)
        // Create string with attachment
        let attachmentString = NSAttributedString(attachment: imageAttachment)
        // Initialize mutable string
        
        let completeText = NSMutableAttributedString(string: labelString)
        // Add image to mutable string
        completeText.append(attachmentString)
        self.attributedText = completeText
    }
    
    public func letterSpacing(_ value: Double = -0.03) {
        let kernValue = self.font.pointSize * CGFloat(value)
        guard let text = text, !text.isEmpty else { return }
        let string = NSMutableAttributedString(string: text)
        string.addAttribute(NSAttributedString.Key.kern,
                            value: kernValue,
                            range: NSRange(location: 0, length: attributedText!.length)) ///NSRange(location: 0, length: string.length - 1))
        attributedText = string

    }
    public func lineHeight(text: String?, lineHeight: CGFloat) {
        if let text = text {
            let style = NSMutableParagraphStyle()
            style.maximumLineHeight = lineHeight
            style.minimumLineHeight = lineHeight
            
            let attributes: [NSAttributedString.Key: Any] = [
                .paragraphStyle: style
            ]
            
            let attrString = NSAttributedString(string: text,
                                                attributes: attributes)
            self.attributedText = attrString
        }
    }
    func underline() {
        if let textString = self.text {
            let attributedString = NSMutableAttributedString(string: textString)
            attributedString.addAttribute(NSAttributedString.Key.underlineStyle,
                                          value: NSUnderlineStyle.styleSingle.rawValue,
                                          range: NSRange(location: 0, length: attributedString.length))
            attributedText = attributedString
       }
   }
}
//MARK: - CustomLabel
@IBDesignable
class CustomLabel: UILabel {
    @IBInspectable var topInset: CGFloat = 5.0
    @IBInspectable var bottomInset: CGFloat = 5.0
    @IBInspectable var leftInset: CGFloat = 7.0
    @IBInspectable var rightInset: CGFloat = 7.0
        
    override var intrinsicContentSize: CGSize {
        let size = super.intrinsicContentSize
        return CGSize(width: size.width + leftInset + rightInset,
                      height: size.height + topInset + bottomInset)
    }
    
    override var bounds: CGRect {
        didSet {
            // ensures this works within stack views if multi-line
            preferredMaxLayoutWidth = bounds.width - (leftInset + rightInset)
        }
    }
    
    @IBInspectable open var letterSpacing:CGFloat = 0 {
        didSet {
            let attributedString = NSMutableAttributedString(string: self.text!)
            attributedString.addAttribute(NSAttributedString.Key.kern, value: self.letterSpacing, range: NSRange(location: 0, length: attributedString.length))
            self.attributedText = attributedString
        }
    }
    
    @IBInspectable open var lineHeight:CGFloat = 0 {
        didSet {
            let attrString = NSMutableAttributedString(string: self.text!)
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.lineSpacing = self.lineHeight
            attrString.addAttribute(NSAttributedString.Key.paragraphStyle, value: paragraphStyle, range: NSMakeRange(0, attrString.length))
            self.attributedText = attrString
        }
    }
}


//MARK: - String --------------------------------------------------
extension String {
    func textHeight(text: String, font: UIFont, width: CGFloat) -> Int {
        let size = CGSize(width: width, height: 2000)
        return Int(text.boundingRect(with: size, options: .usesLineFragmentOrigin, attributes: [.font: font], context: nil).size.height)
    }
    func textWidth(text: String, font: UIFont, height: CGFloat) -> Int {
        let size = CGSize(width: 2000, height: height)
        return Int(text.boundingRect(with: size, options: .usesLineFragmentOrigin, attributes: [.font: font], context: nil).size.width)
    }
    
    func substring(from: Int, to: Int) -> String {
        guard from < count, to >= 0, to - from >= 0 else { return "" }
        ///Index 값 획득
        let startIndex = index(self.startIndex, offsetBy: from)
        let endIndex = index(self.startIndex, offsetBy: to)
        ///파싱
        return String(self[startIndex ..< endIndex])
    }
    func codeSubString(subString:String)->String {
        if subString.contains("hyundai-talktalk://oauth2redirect"){
            let findIdx:String.Index = subString.firstIndex(of: "=")!
            print("codeSubString: \(subString[findIdx...])")
            let eidx = subString[findIdx...]
            print("eidx:\(eidx)")
            let separatedBy = eidx.components(separatedBy: ["="]).joined()
            print("separatedBy:\(separatedBy)")
            return separatedBy
        } else {
            return "CodeSubString: Failture"
        }
    }

    func getWeekDay(monthData: Int = 0, day: Int) -> String {
        let month: Int = self.getCurrentDateTime()
        let dayDay:[String] = ["월", "화", "수", "목", "금", "토", "일"]
        var returnValue: String = ""
        var totalDay: Int = 0
        for i in 1..<month {
            totalDay += endOfMonth(atMonth: i)
        }
        var index: Int = 0
        if (totalDay + day) % 7 == 0 {
            index = 6
        }else {
            index = (totalDay + day) % 7 - 1
        }
        returnValue = dayDay[index]
        return returnValue
    }
    func getCurrentDateTime() -> Int{
        let formatter = DateFormatter()
        formatter.dateStyle = .long
        formatter.timeStyle = .medium
        formatter.dateFormat = "M"
        let str = formatter.string(from: Date())
        return Int(str)!
    }
    func endOfMonth(atMonth: Int) -> Int {
        let set30: [Int] = [1,3,5,7,8,10,12]
        var endDay: Int = 0
        if atMonth == 2 {
            endDay = 28
        } else if set30.contains(atMonth) {
            endDay = 31
        } else {
            endDay = 30
        }
        return endDay
    }
}
extension NSMutableAttributedString {
    func regular(string: String, fontSize: CGFloat) -> NSMutableAttributedString {
        let font = UIFont(name: "Pretendard-Regular", size: fontSize)
        let attributes: [NSAttributedString.Key: Any] = [.font: font as Any]
        self.append(NSAttributedString(string: string, attributes: attributes))
        return self
    }
    func medium(string: String, fontSize: CGFloat) -> NSMutableAttributedString {
        let font = UIFont(name: "Pretendard-Medium", size: fontSize)
        let attributes: [NSAttributedString.Key: Any] = [.font: font as Any]
        self.append(NSAttributedString(string: string, attributes: attributes))
        return self
    }
    func bold(string: String, fontSize: CGFloat) -> NSMutableAttributedString {
        let font = UIFont(name: "Pretendard-Bold", size: fontSize)
        let attributes: [NSAttributedString.Key: Any] = [.font: font as Any]
        self.append(NSAttributedString(string: string, attributes: attributes))
        return self
    }
    func semibold(string: String, fontSize: CGFloat) -> NSMutableAttributedString {
        let font = UIFont(name: "Pretendard-SemiBold", size: fontSize)
        let attributes: [NSAttributedString.Key: Any] = [.font: font as Any]
        self.append(NSAttributedString(string: string, attributes: attributes))
        return self
    }
}



//MARK: Date ----------------------------------------------------
extension Date {
    var millisecondsSince1970: Int64 {
        Int64((self.timeIntervalSince1970 * 1000.0).rounded())
    }
    
    init(milliseconds: Int64) {
        self = Date(timeIntervalSince1970: TimeInterval(milliseconds) / 1000)
    }
    
    //MARK: timestampInMilliseconds
    init(timestampInMilliseconds: Double) {
        self.init(timeIntervalSince1970: timestampInMilliseconds / 1000.0)
    }
    public func isDateInLast24Hours() -> Bool {
        Calendar.current.dateComponents([.day], from: self, to: .now).day! == 0
    }

    //MARK: dateCompare
    public func dateCompare(fromDate: Date) -> String {
        var strDateMessage:String = ""
        let result:ComparisonResult = self.compare(fromDate)
        switch result {
        case .orderedAscending:
            strDateMessage = "Future"
            break
        case .orderedDescending:
            strDateMessage = "Past"
            break
        case .orderedSame:
            strDateMessage = "Same"
            break
        default:
            strDateMessage = "Error"
            break
        }
        return strDateMessage
    }
}
//MARK: Font ---------------------------------------------
func familyFont() {
    let familyNames = UIFont.familyNames
    for familyName in familyNames {
        print( "Family: \(familyName.utf8)" )
        let fontNames = UIFont.fontNames(forFamilyName: familyName)
        for fontName in fontNames {
            print( "\tFont: \(fontName.utf8)")
        }
    }
}



//MARK: - UIView ------------------------------------------------
extension UIView {
    /**
    func getAllConstraints() -> [NSLayoutConstraint] {

            // array will contain self and all superviews
            var views = [self]

            // get all superviews
            var view = self
            while let superview = view.superview {
                views.append(superview)
                view = superview
            }

            // transform views to constraints and filter only those
            // constraints that include the view itself
            return views.flatMap({ $0.constraints }).filter { constraint in
                return constraint.firstItem as? UIView == self ||
                    constraint.secondItem as? UIView == self
            }
        }
    
    func setVisiblity(gone: Bool, dimension: CGFloat = 0.0, attribute: NSLayoutConstraint.Attribute = .height) -> Void {
        if let constraint = (self.getAllConstraints().filter{
            ($0.firstAttribute == .height && $0.firstItem as? UIView == self) || ($0.secondAttribute == .height && $0.secondItem as? UIView == self)
        }.first) {
            constraint.constant = gone ? 0.0 : dimension
            self.layoutIfNeeded()
            self.isHidden = gone
        } else {
//            self.isHidden = gone
        }
    }
    */
    func setVisiblity(gone: Bool, dimension: CGFloat = 0.0, attribute: NSLayoutConstraint.Attribute = .height) -> Void {
        if let constraint = (self.constraints.filter{$0.firstAttribute == attribute}.first) {
            constraint.constant = gone ? 0.0 : dimension
            self.layoutIfNeeded()
            self.isHidden = gone
        } else {
            self.isHidden = gone
        }
        
        /**
        let constraints = self.constraints.filter({$0.firstAttribute == .height && $0.constant == 0 && $0.secondItem == nil && ($0.firstItem as? UIView) == self})
        let constraint = (constraints.first)
        self.isHidden = true
        if let constraint = constraint {
            constraint.isActive = true
        } else {
            let constraint = NSLayoutConstraint(item: self, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1, constant: 0)
            // constraint.priority = UILayoutPriority(rawValue: 999)
            self.addConstraint(constraint)
            constraint.isActive = true
        }
        self.setNeedsLayout()
        self.setNeedsUpdateConstraints()
         */
    }
    static func loadFromNib<T>() -> T? {
        let identifier = String(describing: T.self)
        let view = Bundle.main.loadNibNamed(identifier, owner: self, options: nil)?.first
        return view as? T
    }
    func toImage() -> UIImage {
        let renderer = UIGraphicsImageRenderer(bounds: bounds)
        return renderer.image { rendererContext in
            layer.render(in: rendererContext.cgContext)
        }
    }
    
    //MARK: addShadow
    enum VerticalLocation {
        case bottom
        case top
        case left
        case right
        case center
    }
    func addShadow(location: VerticalLocation, color: UIColor = .black, opacity: Float = 0.8, radius: CGFloat = 5.0) {
        switch location {
        case .bottom:
             addShadow(offset: CGSize(width: 0, height: 10), color: color, opacity: opacity, radius: radius)
        case .top:
            addShadow(offset: CGSize(width: 0, height: -10), color: color, opacity: opacity, radius: radius)
        case .left:
            addShadow(offset: CGSize(width: -10, height: 0), color: color, opacity: opacity, radius: radius)
        case .right:
            addShadow(offset: CGSize(width: 10, height: 0), color: color, opacity: opacity, radius: radius)
        case .center:
            addShadow(offset: CGSize(width: 0, height: 0), color: color, opacity: opacity, radius: radius)
        }
    }
    func addShadow(offset: CGSize, color: UIColor = .black, opacity: Float = 0.1, radius: CGFloat = 3.0) {
        self.layer.masksToBounds = false
        self.layer.shadowColor = color.cgColor
        self.layer.shadowOffset = offset
        self.layer.shadowOpacity = opacity
        self.layer.shadowRadius = radius
    }
    
    
    //MARK: setGradient
    public func setGradientBackground(colorTop: UIColor, colorBottom: UIColor){
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [colorTop.cgColor, colorBottom.cgColor]
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0.0)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1.0)
        gradientLayer.locations = [0, 1]
        gradientLayer.frame = bounds
        layer.insertSublayer(gradientLayer, at: 0)
    }
    
    //MARK: roundCorners
    func roundCorners(cornerRadius: CGFloat, maskedCorners: CACornerMask) {
        clipsToBounds = true
        layer.cornerRadius = cornerRadius
        layer.maskedCorners = CACornerMask(arrayLiteral: maskedCorners)
    }
    
    //MARK: viewToImage
    func viewToImage() -> UIImage {
      let renderer = UIGraphicsImageRenderer(bounds: bounds)
        return renderer.image(actions: { rendererContext in
          layer.render(in: rendererContext.cgContext)
      })
    }
    
    //MARK: addConstraintsWithFormatString
    func addConstraintsWithFormatString(formate: String, views: UIView...) {
        var viewsDictionary = [String: UIView]()
        for (index, view) in views.enumerated() {
            let key = "v\(index)"
            view.translatesAutoresizingMaskIntoConstraints = false
            viewsDictionary[key] = view
        }
        addConstraints(NSLayoutConstraint.constraints(withVisualFormat: formate,
                                                      options: NSLayoutConstraint.FormatOptions(),
                                                      metrics: nil, views: viewsDictionary))
    }
}
//MARK: CALayer -------------------------------------------------
extension CALayer {
    //MARK: defaultShadow
    func defaultShadow(color: UIColor = UIColor(red: 210, green: 218, blue: 226, alpha: 1.0),
                       alpha: CGFloat = 1.0,
                       x: CGFloat = 0,
                       y: CGFloat = 0,
                       opacity: Float = 1.0,
                       blur: CGFloat = 1,
                       spread: CGFloat = 0) {
        masksToBounds = false
        shadowColor = UIColor(red: 210, green: 218, blue: 226, alpha: alpha).cgColor
        shadowOffset = CGSize(width: x, height: y)
        shadowOpacity = opacity
        shadowRadius = blur
    }
    //MARK: applySketchShadow
    func applySketchShadow(color: UIColor = .black,
                           alpha: Float = 0.5,
                           x: CGFloat = 0,
                           y: CGFloat = 2,
                           blur: CGFloat = 4,
                           spread: CGFloat = 0)
    {
        masksToBounds = false
        shadowColor = color.cgColor
        shadowOpacity = alpha
        shadowOffset = CGSize(width: x, height: y)
        shadowRadius = blur / 2.0
        if spread == 0 {
            shadowPath = nil
        } else {
            let dx = -spread
            let rect = bounds.insetBy(dx: dx, dy: dx)
            shadowPath = UIBezierPath(rect: rect).cgPath
        }
    }
}



//MARK: - UIImageView -------------------------------------------
extension UIImageView {
    func setImageVisiblity(gone: Bool, dimension: CGFloat = 0.0, attribute: NSLayoutConstraint.Attribute = .height) -> Void {
        if let constraint = (self.constraints.filter{$0.firstAttribute == attribute}.first) {
            constraint.constant = gone ? 0.0 : dimension
            self.layoutIfNeeded()
            self.isHidden = gone
        }
    }
    
    func imageLoad(url: URL) {
        DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: url) {
                if let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self?.image = image
                    }
                }
            }
        }
    }
    
    func resize(targetSize: CGSize, opaque: Bool = false) -> UIImage? {
          UIGraphicsBeginImageContextWithOptions(targetSize, opaque, 0)
          guard let context = UIGraphicsGetCurrentContext() else { return nil }
          context.interpolationQuality = .high
        
          let newRect = CGRect(x: 0, y: 0, width: targetSize.width, height: targetSize.height)
            draw(newRect)
      
          let newImage = UIGraphicsGetImageFromCurrentImageContext()
          UIGraphicsEndImageContext()
          return newImage
      }
}
//MARK: UIImage -------------------------------------------------
extension UIImage {
    func resizeImage(image: UIImage, newWidth: CGFloat) -> UIImage {
        let scale = newWidth / image.size.width
        let newHeight = image.size.height * scale
        UIGraphicsBeginImageContext(CGSize(width: newWidth, height: newHeight))
        image.draw(in: CGRect(x: 0, y: 0, width: newWidth, height: newHeight))
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return newImage!
    }
}



//MARK: - UIButton ----------------------------------------------
extension UIButton {
    func setGradient(color1:UIColor,color2:UIColor){
        let gradient: CAGradientLayer = CAGradientLayer()
        gradient.colors = [color1.cgColor,color2.cgColor]
        gradient.locations = [0.0 , 1.0]
        gradient.startPoint = CGPoint(x: 0.0, y: 1.0)
        gradient.endPoint = CGPoint(x: 1.0, y: 1.0)
        gradient.frame = bounds
        layer.addSublayer(gradient)
    }
    
    func letterSpacing(value: CGFloat) {
        let attributedText = NSMutableAttributedString(string: (self.titleLabel?.text)!)
        attributedText.addAttribute(NSAttributedString.Key.kern, value: value, range: NSRange(location: 0, length: attributedText.length))
        self.titleLabel?.attributedText = attributedText
    }
    
    func setUnderline() {
        guard let title = title(for: .normal) else { return }
        let attributedString = NSMutableAttributedString(string: title)
        attributedString.addAttribute(.underlineStyle,
                                      value: NSUnderlineStyle.styleSingle.rawValue,
                                      range: NSRange(location: 0, length: title.count)
        )
        setAttributedTitle(attributedString, for: .normal)
    }
}



//MARK: - UITextView --------------------------------------------
extension UITextView {
    func centerVertically() {
        let fittingSize = CGSize(width: bounds.width, height: CGFloat.greatestFiniteMagnitude)
        let size = sizeThatFits(fittingSize)
        let topOffset = (bounds.size.height - size.height * zoomScale) / 2
        let positiveTopOffset = max(1, topOffset)
        contentOffset.y = -positiveTopOffset
    }
    func numberOfLine() -> CGFloat {
        let size = CGSize(width: frame.width, height: .infinity)
        let estimatedSize = sizeThatFits(size)
        return estimatedSize.height
    }
    public func lineHeight(text: String?, lineHeight: CGFloat) {
        if let text = text {
            let style = NSMutableParagraphStyle()
            style.maximumLineHeight = lineHeight
            style.minimumLineHeight = lineHeight
            
            let attributes: [NSAttributedString.Key: Any] = [
                .paragraphStyle: style
            ]
            
            let attrString = NSAttributedString(string: text,
                                                attributes: attributes)
            self.attributedText = attrString
        }
    }
}



//MARK: - UITextField -------------------------------------------
extension UITextField {
    func setLeftPaddingPoints(_ amount:CGFloat){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.leftView = paddingView
        self.leftViewMode = .always
    }
}



//MARK: - UITableViewCell -------------------------------------------
extension UITableViewCell {
    func setCellVisiblity(gone: Bool, dimension: CGFloat = 0.0, attribute: NSLayoutConstraint.Attribute = .height) -> Void {
        if let constraint = (self.constraints.filter{$0.firstAttribute == attribute}.first) {
            constraint.constant = gone ? 0.0 : dimension
            self.layoutIfNeeded()
            self.isHidden = gone
        }
    }
}



//MARK: - UIDevice -----------------------------------------------
extension UIDevice {
    static func vibrate() {
        AudioServicesPlaySystemSound(kSystemSoundID_Vibrate)
    }
}
enum Vibration: String, CaseIterable {
    static var allCases: [Vibration] {
        let defaultList = [light, medium, heavy]
        return defaultList
    }
    case light, medium, heavy
    public func vibrate() {
        switch self {
        case .light:
            UIImpactFeedbackGenerator(style: .light).impactOccurred()
        case .medium:
            UIImpactFeedbackGenerator(style: .medium).impactOccurred()
        case .heavy:
            UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
        }
    }
}
