//
//  UIAlertController+.swift
//  Offline-Test
//
//  Created by Shock on 2020/11/11.
//

import UIKit

public extension UIAlertController {
    // 확인 얼럿
    static func alert(_ controller: UIViewController, title: String, message: String?, completed: ((UIAlertAction) -> Void)? = nil) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "확인", style: .cancel, handler: completed))
        DispatchQueue.main.async {
            controller.present(alert, animated: true)
        }
    }
    
    // 확인/취소 얼럿
    static func confirm(_ controller: UIViewController, title: String, message: String, completed: @escaping ((Bool) -> Void)) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "확인", style: .default) { _ in completed(true) })
        alert.addAction(UIAlertAction(title: "취소", style: .cancel) { _ in completed(false) })
        DispatchQueue.main.async {
            controller.present(alert, animated: true)
        }
    }
    
    // 확인/취소 커스텀 버튼 얼럿
    static func confirmCustom(_ controller: UIViewController, title: String, message: String, okTitle: String? = nil, cancelTitle: String? = nil, completed: ((Bool) -> Void)? = nil) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        if let okTitle = okTitle {
            alert.addAction(UIAlertAction(title: okTitle, style: .default) { _ in completed?(true) })
        }
        
        if let cancelTitle = cancelTitle {
            alert.addAction(UIAlertAction(title: cancelTitle, style: .cancel) { _ in completed?(false) })
        }
        
        DispatchQueue.main.async {
            controller.present(alert, animated: true)
        }
    }
    
    static func loading(_ controller: UIViewController, completed: @escaping ((UIAlertController) -> Void)) {
        let alert = UIAlertController(title: "", message: nil, preferredStyle: .alert)
        let activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .large)
        
        activityIndicator.color = .white
        activityIndicator.translatesAutoresizingMaskIntoConstraints = false
        activityIndicator.isUserInteractionEnabled = false
        activityIndicator.startAnimating()
        
        alert.view.addSubview(activityIndicator)
        alert.view.heightAnchor.constraint(equalToConstant: 70).isActive = true
        alert.view.widthAnchor.constraint(equalToConstant: 70).isActive = true
                        
        activityIndicator.centerXAnchor.constraint(equalTo: alert.view.centerXAnchor, constant: 0).isActive = true
        activityIndicator.centerYAnchor.constraint(equalTo: alert.view.centerYAnchor, constant: 0).isActive = true
        
        if let bgView = alert.view.subviews.first, let groupView = bgView.subviews.first, let contentView = groupView.subviews.first {
            contentView.backgroundColor = UIColor.darkGray
        }
        
        DispatchQueue.main.async {
            controller.present(alert, animated: true) {
                completed(alert)
            }
        }
    }
}
