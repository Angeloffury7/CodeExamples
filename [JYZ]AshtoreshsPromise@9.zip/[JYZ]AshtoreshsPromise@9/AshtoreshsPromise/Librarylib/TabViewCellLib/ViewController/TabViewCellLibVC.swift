//
//  ViewController.swift
//  ViewPager
//
//  Created by Zafar on 14/08/21.
//

import UIKit


class TabViewCellLibVC: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initViewPager()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationItem.title = "ViewPager"
        self.navigationController?.navigationBar.standardAppearance.backgroundColor = .systemBlue
        self.navigationController?.navigationBar.standardAppearance.titleTextAttributes = [.foregroundColor: UIColor.white]
    }
}
extension TabViewCellLibVC {
    public func initViewPager() {
         lazy var viewPager: ViewPager = {
            let viewPager = ViewPager(
                tabSizeConfiguration: .fillEqually(height: 44, spacing: 0)
            )
            let view1 = UIView()
            view1.backgroundColor = .red
            let view2 = UIView()
            view2.backgroundColor = .green
            let view3 = UIView()
            view3.backgroundColor = .blue
            let view4 = UIView()
            view4.backgroundColor = .orange
            let view5 = UIView()
            view5.backgroundColor = .purple
            
            viewPager.tabbedView.tabs = [
                AppTabItemView(title: "Tab I"),
                AppTabItemView(title: "Tab II"),
                AppTabItemView(title: "Tab III"),
                AppTabItemView(title: "Tab IV"),
                AppTabItemView(title: "Tab V")
            ]
            viewPager.pagedView.pages = [
                view1,
                view2,
                view3,
                view4,
                view5
            ]
            viewPager.translatesAutoresizingMaskIntoConstraints = false
            return viewPager
        }()
        
        self.overrideUserInterfaceStyle = .light
        self.view.backgroundColor = .white
        self.view.addSubview(viewPager)
        NSLayoutConstraint.activate([
            viewPager.widthAnchor.constraint(equalTo: self.view.widthAnchor),
            viewPager.heightAnchor.constraint(equalTo: self.view.heightAnchor, multiplier: 1.0),
            viewPager.centerXAnchor.constraint(equalTo: self.view.centerXAnchor),
            viewPager.topAnchor.constraint(equalTo: self.view.safeAreaLayoutGuide.topAnchor)
        ])
    }
}
