//
//  EditMode.swift
//  DemoArcade
//
//  Created by Jonathan Rasmusson Work Pro on 2020-04-10.
//  Copyright © 2020 Rasmusson Software Consulting. All rights reserved.
//

/*
Abstract:
Sample demonstrating UITableViewDiffableDataSource using editing, reordering and header/footer titles support
*/

import UIKit


//MARK: - Customtypealias
typealias CustomSectionType = CustomSection
typealias CustomItemType = MountainsController.Mountain


//MARK: - CustomSection
public enum CustomSection: Int {
    case visited = 0, bucketList
    func description() -> String {
        switch self {
        case .visited:
            return "Visited"
        case .bucketList:
            return "Bucket List"
        }
    }
    func secondaryDescription() -> String {
        switch self {
        case .visited:
            return "Trips I've made!"
        case .bucketList:
            return "Need to do this before I go!"
        }
    }
}


//MARK: - CustomEditModeVC
class CustomEditModeVC: UIViewController {
    //MARK: Variables
    @IBOutlet weak var mainVC: UIView!
    
    //MARK: Variables
    public let reuseIdentifier = "reuse-id"
    ///Subclassing our data source to supply various UITableViewDataSource methods
    public var dataSource: CustomMoveableCellDataSource!
    public var tableView: UITableView!
    public var pageIndex: Int!
    
    //MARK: ViewLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        self.configureHierarchy()
        self.configureDataSource()
        self.configureNavigationItem()
    }
}
extension CustomEditModeVC {
    public func configureHierarchy() {
        self.tableView = UITableView(frame: .zero, style: .insetGrouped)
        self.tableView.translatesAutoresizingMaskIntoConstraints = false
        self.tableView.register(UITableViewCell.self, forCellReuseIdentifier: reuseIdentifier)
        ///view.addSubview(tableView)
        self.mainVC.addSubview(self.tableView)
        NSLayoutConstraint.activate([
            self.tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            self.tableView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            self.tableView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor),
            self.tableView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor)
        ])
    }
    public func configureDataSource() {
        let formatter = NumberFormatter()
        formatter.groupingSize = 3
        formatter.usesGroupingSeparator = true
        ///data source
        self.dataSource = CustomMoveableCellDataSource(tableView: tableView) { (tableView, indexPath, mountain) -> UITableViewCell? in
            guard let cell = tableView.dequeueReusableCell(withIdentifier: self.reuseIdentifier) else {
                return UITableViewCell(style: .subtitle, reuseIdentifier: self.reuseIdentifier)
            }

            cell.textLabel?.text = mountain.name
            if let formattedHeight = formatter.string(from: NSNumber(value: mountain.height)) {
                cell.detailTextLabel?.text = "\(formattedHeight)M"
            }
            return cell
        }
        ///initial data
        let snapshot = initialSnapshot()
        self.dataSource.apply(snapshot, animatingDifferences: false)
    }
    public func initialSnapshot() -> NSDiffableDataSourceSnapshot<CustomSectionType, CustomItemType> {
        let mountainsController = MountainsController()
        let limit = 8
        let mountains = mountainsController.filteredMountains(limit: limit)
        let bucketList = Array(mountains[0..<limit / 2])
        let visited = Array(mountains[limit / 2..<limit])

        var snapshot = NSDiffableDataSourceSnapshot<CustomSectionType, CustomItemType>()
        snapshot.appendSections([.visited])
        snapshot.appendItems(visited)
        snapshot.appendSections([.bucketList])
        snapshot.appendItems(bucketList)
        return snapshot
    }
    public func configureNavigationItem() {
        navigationItem.title = "Edit Mode"
        let editingItem = UIBarButtonItem(title: tableView.isEditing ? "Done" : "Edit", style: .plain, target: self, action: #selector(toggleEditing))
        self.navigationItem.rightBarButtonItems = [editingItem]
    }
    
    @objc public func toggleEditing() {
        self.tableView.setEditing(!tableView.isEditing, animated: true)
        self.configureNavigationItem()
    }
}


//MARK: - CustomMoveableCellDataSource
class CustomMoveableCellDataSource: UITableViewDiffableDataSource<CustomSectionType, CustomItemType> {
    //MARK: header/footer titles support
    override public func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        let sectionKind = CustomSection(rawValue: section)
        return sectionKind?.description()
    }
    override public func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        let sectionKind = CustomSection(rawValue: section)
        return sectionKind?.secondaryDescription()
    }
    
    //MARK: reordering support
    override public func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    override public func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        ///get our source & destination (from & to)
        guard let sourceIdentifier = itemIdentifier(for: sourceIndexPath) else { return }
        guard sourceIndexPath != destinationIndexPath else { return }
        let destinationIdentifier = itemIdentifier(for: destinationIndexPath)
        ///take snapshot before
        var snapshot = self.snapshot()
        ///if moving within a section
        if let destinationIdentifier = destinationIdentifier {
            guard let sourceIndex = snapshot.indexOfItem(sourceIdentifier) else { return }
            guard let destinationIndex = snapshot.indexOfItem(destinationIdentifier) else { return }
            ///delete it
            snapshot.deleteItems([sourceIdentifier])

            ///figure out if before or after (and double check same section)
            let isAfter = destinationIndex > sourceIndex &&
                snapshot.sectionIdentifier(containingItem: sourceIdentifier) ==
                snapshot.sectionIdentifier(containingItem: destinationIdentifier)
                            
            ///insert back either before or after
            if isAfter {
                snapshot.insertItems([sourceIdentifier], afterItem: destinationIdentifier)
            } else {
                snapshot.insertItems([sourceIdentifier], beforeItem: destinationIdentifier)
            }
        } else {
            ///move between sections
            ///get the new destination section
            let destinationSectionIdentifier = snapshot.sectionIdentifiers[destinationIndexPath.section]
            ///delete where it was
            snapshot.deleteItems([sourceIdentifier])
            ///add to where it is going
            snapshot.appendItems([sourceIdentifier], toSection: destinationSectionIdentifier)
        }
        self.apply(snapshot, animatingDifferences: false)
    }
    
    //MARK: editing support
    override public func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    override public func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        ///when deleting a row...
        if editingStyle == .delete {
            if let identifierToDelete = itemIdentifier(for: indexPath) {
                var snapshot = self.snapshot()
                snapshot.deleteItems([identifierToDelete])
                apply(snapshot)
            }
        }
    }
}


