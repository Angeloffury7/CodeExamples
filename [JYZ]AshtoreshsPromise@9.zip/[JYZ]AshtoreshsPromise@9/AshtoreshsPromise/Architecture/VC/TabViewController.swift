//
//  TabViewController.swift
//  TabsExample
//
//  Created by John Codeos on 5/22/20.
//  Copyright © 2020 John Codeos. All rights reserved.
//

import UIKit


//MARK: - TabView(UIViewController)
class TabViewController: UIViewController {
    //MARK: - @IBOutlet
    @IBOutlet var tabsView: TabsView!
    
    //MARK: - Variable
    public weak var coordinator: BaseCoordinator!
    public var pageController: UIPageViewController!
    public var currentIndex: Int = 0
    
    //MARK: - ViewLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        //MARK: TabVC
        self.setupTabs()
        self.setupPageViewController()
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        // Refresh CollectionView Layout when you rotate the device
        self.tabsView.collectionView.collectionViewLayout.invalidateLayout()
    }
}


//MARK: - TabBar(Sce22222222``2d2neVC)
extension TabViewController {
    //MARK: TabBarIndex(currentIndex)
    ///Show showViewController for the current position
    public func showViewController(_ index: Int) -> UIViewController? {
        if (self.tabsView.tabs.count == 0) || (index >= self.tabsView.tabs.count) {
            return nil
        }
        //MARK: showViewController의 currentIndex로 인하여 PageController 이동 후 바로 2가 되는 현상 발생함
        ///self.currentIndex = index
        print("scrollViewDidScroll(CurrentIndex)_A:\(self.currentIndex)")
        if index == 0 {
            let contentVC = storyboard?.instantiateViewController(withIdentifier: "CustomMainVC") as! CustomMainVC
            ///contentVC.name = tabsView.tabs[index].title
            contentVC.pageIndex = index
            return contentVC
        } else if index == 1 {
            let contentVC = storyboard?.instantiateViewController(withIdentifier: "CustomTableVC") as! CustomTableVC
            ///contentVC.name = tabsView.tabs[index].title
            contentVC.pageIndex = index
            return contentVC
        } else if index == 2 {
            let contentVC = storyboard?.instantiateViewController(withIdentifier: "CustomFruitVC") as! CustomFruitVC
            ///contentVC.name = tabsView.tabs[index].title
            contentVC.pageIndex = index
            return contentVC
        } else {
            let contentVC = storyboard?.instantiateViewController(withIdentifier: "CustomMainVC") as! CustomMainVC
            ///contentVC.name = tabsView.tabs[index].title
            contentVC.pageIndex = index
            return contentVC
        }
    }
    //MARK: TabBarIndex(getVCPageIndex)
    ///Return the current position that is saved in the UIViewControllers we have in the UIPageViewController
    public func getVCPageIndex(_ viewController: UIViewController?) -> Int {
        switch viewController {
        case is CustomMainVC:
            let vc = viewController as! CustomMainVC
            return vc.pageIndex
        case is CustomTableVC:
            let vc = viewController as! CustomTableVC
            return vc.pageIndex
        case is CustomFruitVC:
            let vc = viewController as! CustomFruitVC
            return vc.pageIndex
        default:
            let vc = viewController as! CustomMainVC
            return vc.pageIndex
        }
    }
}


//MARK: - TabVC(Setup)
extension TabViewController {
    public func setupTabs() {
        ///Add Tabs (Set 'icon'to nil if you don't want to have icons)
        self.tabsView.tabs = [
            Tab(icon: UIImage(named: "music"), title: "Tab I"),
            Tab(icon: UIImage(named: "movies"), title: "Tab II"),
            Tab(icon: UIImage(named: "books"), title: "Tab III")
        ]
        ///Set TabMode to '.fixed' for stretched tabs in full width of screen or '.scrollable' for scrolling to see all tabs
        self.tabsView.tabMode = .fixed
        ///TabView Customization
        self.tabsView.titleColor = .white
        self.tabsView.iconColor = .white
        self.tabsView.indicatorColor = .white
        self.tabsView.titleFont = UIFont.systemFont(ofSize: 18, weight: .semibold)
        ///tabsView.collectionView.backgroundColor = .cyan
        ///Set TabsView Delegate
        self.tabsView.delegate = self
        ///Set the selected Tab when the app starts
        self.tabsView.collectionView.selectItem(at: IndexPath(item: 0, section: 0), 
                                                animated: true,
                                                scrollPosition: .centeredVertically)
    }
    public func setupPageViewController() {
        self.pageController = UIPageViewController.init(transitionStyle: UIPageViewController.TransitionStyle.scroll, navigationOrientation: UIPageViewController.NavigationOrientation.horizontal, options: nil)
        
        self.pageController.view.backgroundColor = UIColor.clear
        self.pageController.delegate = self
        self.pageController.dataSource = self
        
        let scrollView = self.pageController.view.subviews
            .compactMap { $0 as? UIScrollView }
            .first
        scrollView?.delegate = self
        scrollView?.isScrollEnabled = true
        
        ///Set the selected ViewController in the PageViewController when the app starts
        self.pageController.setViewControllers([self.showViewController(0)!],
                                               direction: .forward,
                                               animated: true,
                                               completion: nil)
        
        ///PageViewController Constraints
        self.view.addSubview(self.pageController.view)
        self.pageController.view.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            self.pageController.view.topAnchor.constraint(equalTo: self.tabsView.bottomAnchor),
            self.pageController.view.leadingAnchor.constraint(equalTo: self.view.leadingAnchor),
            self.pageController.view.trailingAnchor.constraint(equalTo: self.view.trailingAnchor),
            self.pageController.view.bottomAnchor.constraint(equalTo: self.view.bottomAnchor)
        ])
        self.pageController.didMove(toParentViewController: self)
    }
}


//MARK: - TabsDelegate
extension TabViewController: TabsDelegate {
    public func tabsViewDidSelectItemAt(position: Int) {
        ///Check if the selected tab cell position is the same with the current position in pageController, if not, then go forward or backward
        var pageDir: Int? = nil
        if(self.currentIndex < position) {
            pageDir = UIPageViewController.NavigationDirection.forward.rawValue
        } else{
            pageDir = UIPageViewController.NavigationDirection.reverse.rawValue
        }
        print("scrollViewDidScroll(currentIndex:\(self.currentIndex)|position:\(position)|pageDir:\(String(describing: pageDir)))")
        self.pageController.setViewControllers([self.showViewController(position)!],
                                               direction: UIPageViewController.NavigationDirection(rawValue: pageDir!)!,
                                               animated: true,
                                               completion: nil)
        self.tabsView.collectionView.scrollToItem(at: IndexPath(item: position, section: 0),
                                                  at: .centeredHorizontally,
                                                  animated: true)
        self.currentIndex = position
    }
}
//MARK: - UIPageViewControllerDelegate
extension TabViewController: UIPageViewControllerDataSource, UIPageViewControllerDelegate {
    ///return ViewController when go forward
    func pageViewController(_ pageViewController: UIPageViewController, 
                            viewControllerAfter viewController: UIViewController) -> UIViewController? {
        var index:Int = self.getVCPageIndex(pageViewController.viewControllers?.first)
        ///Don't do anything when viewpager reach the number of tabs
        if index == self.tabsView.tabs.count {
            return nil
        } else {
            index += 1
            return self.showViewController(index)
        }
    }
    ///return ViewController when go backward
    func pageViewController(_ pageViewController: UIPageViewController, 
                            viewControllerBefore viewController: UIViewController) -> UIViewController? {
        var index:Int = self.getVCPageIndex(pageViewController.viewControllers?.first)
        if index == 0 {
            return nil
        } else {
            index -= 1
            return self.showViewController(index)
        }
    }
    func pageViewController(_ pageViewController: UIPageViewController, 
                            didFinishAnimating finished: Bool, 
                            previousViewControllers: [UIViewController],
                            transitionCompleted completed: Bool) {
        ///if finished && completed {}
        if completed {
            print("scrollViewDidScroll(CurrentIndex)_B:\(self.currentIndex)")
            self.currentIndex = self.getVCPageIndex(pageViewController.viewControllers?.first)
            self.tabsView.collectionView.selectItem(at: IndexPath(item: self.currentIndex, section: 0),
                                                    animated: true,
                                                    scrollPosition: .centeredVertically)
            ///Animate the tab in the TabsView to be centered when you are scrolling using .scrollable
            self.tabsView.collectionView.scrollToItem(at: IndexPath(item: self.currentIndex, section: 0),
                                                      at: .centeredHorizontally,
                                                      animated: true)
        }
    }
}


//MARK: - UIScrollViewDelegate
extension TabViewController: UIScrollViewDelegate {
    internal func scrollViewDidScroll(_ scrollView: UIScrollView) {
        print("scrollViewDidScroll(CurrentIndex)_B:\(self.currentIndex)")
        print(scrollView.bounces, scrollView.contentOffset)
        if ( (self.currentIndex <= 0) && (scrollView.contentOffset.x < scrollView.frame.width) )  {
            scrollView.bounces = false
            scrollView.isScrollEnabled = false
        } else if( (self.currentIndex >= self.tabsView.tabs.count-1) && (scrollView.contentOffset.x > scrollView.frame.width) ) {
            scrollView.bounces = false
            scrollView.isScrollEnabled = false
        } else {
            scrollView.bounces = true
            scrollView.isScrollEnabled = true
        }
    }
}
