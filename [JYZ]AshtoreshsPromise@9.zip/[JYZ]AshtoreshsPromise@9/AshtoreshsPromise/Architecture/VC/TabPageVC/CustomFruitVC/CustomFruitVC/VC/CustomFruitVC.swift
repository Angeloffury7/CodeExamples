//
//  CustomFruitVC.swift
//  AshtoreshsLibrary
//
//  Created by holgermayer on 08.09.18.
//  Copyright © 2018 holgermayer. All rights reserved.
//

import UIKit
import RealmSwift


//MARK: - UIButton(Custom)
extension UIButton {
open override var isHighlighted: Bool {
    didSet {
        super.isHighlighted = false
    }
}}


//MARK: - CustomFruitVC
class CustomFruitVC: UIViewController {
    //MARK: - @IBOutlet
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var editButton: UIButton!
    //MARK: Coordinator
    public var coordinator: MoveCoordinator = MoveCoordinator()
    //MARK: - Variables
    public var pageIndex: Int!
    public var dataSource: ObjectAdapterProtocol? { didSet {}}  ///self.tableView.reloadData()
    //MARK: RealmDB
    ///public let realmDatabase = try! Realm()
    public let realmTempData = RealmTempModel()
    
    
    //MARK: ViewLoads
    override func viewDidLoad() {
        super.viewDidLoad()
        //MARK: clearsSelectionOnViewWillAppear
        ///Uncomment the following line to preserve selection between presentations
        ///self.clearsSelectionOnViewWillAppear = false
        ///Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        ///self.navigationItem.rightBarButtonItem = self.editButtonItem
        
        //MARK: dataSource
        self.dataSource = FruitAdapter()
        guard let dataSource = self.dataSource else { return }
        dataSource.registerCells(in: self.tableView)
        self.tableView.accessibilityIdentifier = "ArrayObjectTableView"
        self.tableView.sectionHeaderTopPadding = 0
        
        //MARK: NaviButton
        ///navigationItem.rightBarButtonItem = editButtonItem
        
        //MARK: RealmDB
        ///self.realmTempModel.dataString = "RealmDB_EmptyData"
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated .
    }
}


//MARK: - @IBAction
extension CustomFruitVC {
    @IBAction func menuButton(_ sender: UIButton) {
        if 0 == sender.tag {
            self.tableView.setEditing(!self.tableView.isEditing, animated: true)
            self.editButton.isSelected = !self.tableView.isEditing
            ///self.editButton.isHighlighted = false
            if self.editButton.isSelected {
                self.editButton.setTitleColor(UIColor.white, for: .normal)
                self.editButton.setTitle("Edit", for: .normal)
            } else {
                self.editButton.setTitleColor(UIColor.red, for: .normal)
                self.editButton.setTitle("Done", for: .normal)
            }
            ///self.editButton.layoutIfNeeded()
        } else if 1 == sender.tag {
            self.coordinator.realmMVC(for: self)
        }
    }
}


//MARK: - TableView DataSource
extension CustomFruitVC: UITableViewDelegate, UITableViewDataSource {
    //MARK: EditForInSection
    public func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    public func tableView(_ tableView: UITableView,
                          commit editingStyle: UITableViewCellEditingStyle,
                          forRowAt indexPath: IndexPath) {
        guard let dataSource = self.dataSource else {
            print("Warning : DemoTableViewController datasource not set")
            return
        }
        if editingStyle == .delete {
            ///self.itemName.remove(at: indexPath.row)
            dataSource.deleteObjectFor(section:indexPath.section, row:indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            ///Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
            ///tableView.insertRows(at: [indexPath], with: .fade)
        } else {
            ///self.testData.insert(self.testData[indexPath.row], at: indexPath.row + 1)
            ///self.tableView.insertRows(at: [indexPath], with: .automatic)
        }
    }
    //MARK: SwipeActions
    func tableView(_ tableView: UITableView,
                   leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let action = UIContextualAction(style: .normal,
                                        title: "Favourite") { [weak self] (action, view, completionHandler) in
                                                
            self?.handleMarkAsFavourite(tableView: tableView, indexPath: indexPath)
            completionHandler(true)
        }
        action.backgroundColor = UIColor.blue
        return UISwipeActionsConfiguration(actions: [action])
    }
    private func handleMarkAsFavourite(tableView:UITableView, indexPath:IndexPath) {
        print("Marked as favourite")
        //MARK: RealmDB(Create)
        do {
            try RealmDataBaseLib.sharedManager.database.write {
                let object = self.dataSource!.objectFor(section: indexPath.section, row: indexPath.row)
                let string = object as? String
                self.realmTempData.dataList.append("\(indexPath)realmTempData:\(String(describing: string))")
                RealmDataBaseLib.sharedManager.database.add(self.realmTempData, update: .all)
            }
        } catch let error {
            print("Error create: \(error)")
        }
    }
    
    
    //MARK: HeightForInSection
    public func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 68.0
    }
    public func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 0.0
    }
    
    
    //MARK: ViewForInSection
    public func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        guard let dataSource = self.dataSource else {
            print("Warning : DemoTableViewController datasource not set")
            return nil
        }
        let title =  dataSource.sectionTitleFor(section: section)
        ///Dequeue with the reuse identifier
        let headerID = dataSource.sectionHeaderIDFor(section: section)
        let header = self.tableView.dequeueReusableHeaderFooterView(withIdentifier: headerID) as? GroupHeaderView
        header?.delegate = self
        header?.section = section
        header?.headerLabel?.text = title
        header?.accessibilityIdentifier = title
        return header
    }
    
    
    //MARK: NumberOfSections
    public func numberOfSections(in tableView: UITableView) -> Int {
        guard let dataSource = self.dataSource else {
            return 0
        }
        return dataSource.numberOfSections()
    }
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        guard let dataSource = self.dataSource else {
            return 0
        }
        return dataSource.numberOfRowsInSection(section: section)
    }
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let dataSource = self.dataSource else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "BasicCellID", for: indexPath)
            cell.textLabel?.text = "DataSource not set"
            return cell
        }
        let cellID = dataSource.cellIDFor(section: indexPath.section, row: indexPath.row)
        let cell = tableView.dequeueReusableCell(withIdentifier: cellID, for: indexPath)
        ///Configure the cell...
        let object = dataSource.objectFor(section: indexPath.section, row: indexPath.row)
        if object != nil {
            guard var commonCell = cell as? CommonTableViewCellProtocol else {
                let string = object as? String
                if string != nil {
                    cell.textLabel?.text = string
                    cell.accessibilityIdentifier = string
                } else {
                    cell.textLabel?.text = "Object is no string"
                }
                return cell
            }
            commonCell.delegate = self
            commonCell.content = object
            commonCell.section = indexPath.section
        } else {
            cell.textLabel?.text = "No object found"
        }
        return cell
    }
    
    //MARK: DraggingCells
    public func tableView(_ tableView: UITableView,
                          targetIndexPathForMoveFromRowAt sourceIndexPath: IndexPath, 
                          toProposedIndexPath proposedDestinationIndexPath: IndexPath) -> IndexPath {
        if sourceIndexPath.section != proposedDestinationIndexPath.section {
            var row = 0
            if sourceIndexPath.section < proposedDestinationIndexPath.section {
                row = self.tableView(tableView, numberOfRowsInSection: sourceIndexPath.section) - 1
            }
            return IndexPath(row: row, section: sourceIndexPath.section)
        }
        return proposedDestinationIndexPath
    }
    public func tableView(_ tableView: UITableView, 
                          moveRowAt sourceIndexPath: IndexPath,
                          to destinationIndexPath: IndexPath) {
        guard let dataSource = self.dataSource else {
            print("Warning: DemoTableViewController datasource not set")
            return
        }
        dataSource.moveRowAtSection(sourceSection:sourceIndexPath.section, 
                                    moveRowAtRow:sourceIndexPath.row,
                                    toDestinationSection:destinationIndexPath.section,
                                    destinationRow:destinationIndexPath.row)
    }
}


//MARK: - GroupHeaderViewDelegate
extension CustomFruitVC : GroupHeaderViewDelegate {
    public func didHitAddAction(_ headerView: GroupHeaderView) {
        //MARK: TableView(InsertRows)
        guard let dataSource = self.dataSource else {
            print("Warning: DemoTableViewController datasource not set")
            return
        }
        let indexPath = dataSource.addObjectTo(section:headerView.section)
        self.tableView.insertRows(at: [indexPath], with: .right)
        print("indexPath:\([indexPath])")
        self.tableView.reloadData()
        
        //MARK: RealmDB(Create)
        do {
            try RealmDataBaseLib.sharedManager.database.write {
                //MARK: Swipeable(Test_I)
                ///URL(https://stackoverflow.com/questions/60532033/realm-ios-how-to-update-list)
                ///self.realmTempModel.dataString = "RealmTableData"
                ///self.realmTempData.dataList.append("\(indexPath)realmTempData")
                ///self.realmTempData.dataList.append(dataSource!.cellIDFor(section: indexPath.section, row: indexPath.row) )
                ///let cellID = dataSource!.cellIDFor(section: indexPath.section, row: indexPath.row)
                ///let cell = tableView.dequeueReusableCell(withIdentifier: cellID, for: indexPath)
                //MARK: Swipeable(Test_II)
                ///Configure the cell...
                ///let object = self.dataSource!.objectFor(section: indexPath.section, row: indexPath.row)
                ///let string = object as? String
                self.realmTempData.dataList.append("\(indexPath)realmTempData:\(String(describing:"didHitAddAction"))")
                RealmDataBaseLib.sharedManager.database.add(self.realmTempData, update: .all)
            }
        } catch let error {
            print("Error create: \(error)")
        }
    }
}
extension CustomFruitVC: EditableFruitTableViewCellDelegate {
    public func editableFruitTableViewCellRequestUniqueNames(for section:Int) -> [String] {
        guard let dataSource = self.dataSource else {
            print("Warning: DemoTableViewController datasource not set")
            return [String]()
        }
        return dataSource.uniqueNames(for :section)
    }
    public func editableFruitTableViewCellBeginEditing(_ cell: EditableFruitTableViewCell) {
    }
    public func editableFruitTableViewCellValueDidChange(_ cell: EditableFruitTableViewCell, 
                                                         value: Any?) {
    }
}
