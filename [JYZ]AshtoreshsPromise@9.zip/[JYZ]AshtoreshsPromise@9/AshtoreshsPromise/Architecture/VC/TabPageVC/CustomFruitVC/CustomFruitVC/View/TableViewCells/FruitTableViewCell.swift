//
//  FruitTableViewCell.swift
//  TableViewTestDemo
//
//  Created by holgermayer on 08.09.18.
//  Copyright © 2018 holgermayer. All rights reserved.
//

import UIKit

class FruitTableViewCell: UITableViewCell, CommonTableViewCellProtocol {
    //MARK: Variable
    public var content : Any? {
        didSet {
            guard let fruit = content as? Fruit else {
                self.textLabel?.text = "Error"
                self.detailTextLabel?.text = "no fruit object"
                return
            }
            self.accessibilityIdentifier = fruit.name
            self.textLabel?.text = fruit.name
            self.detailTextLabel?.text = "\(fruit.price)"
        }
    }
    public var delegate: EditableFruitTableViewCellDelegate?
    public var section: Int = -1

    //MARK: awakeFromNib
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
}
