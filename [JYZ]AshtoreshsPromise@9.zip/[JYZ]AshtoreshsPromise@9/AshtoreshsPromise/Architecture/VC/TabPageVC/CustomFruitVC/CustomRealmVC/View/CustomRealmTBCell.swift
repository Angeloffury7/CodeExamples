//
//  CustomRealmTBCell.swift
//  SampleSource
//
//  Created by HanilNW on 2023/07/03.
//

import UIKit


//MARK: - UITableViewCell(Class)
class CustomRealmTBCell: UITableViewCell {
    //MARK: @IBOutlet
    @IBOutlet var showView: UIView!
    @IBOutlet var iconImgView: UIImageView!
    @IBOutlet var explainLabel: UILabel!
    @IBOutlet var timeLabel: UILabel!
    @IBOutlet var dataLabel: UILabel!

    
    //MARK: layoutSubviews
    override func layoutSubviews() {
        super.layoutSubviews()
        ///self.contentView.frame = contentView.frame.inset(by: UIEdgeInsets(top: 0, left: 0, bottom: 12, right: 0))
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        ///Initialization code
        self.initializeCell()
    }
    
    
    //MARK: setSelected
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        ///Configure the view for the selected state
    }
}
//MARK: - UITableViewCell(extension)
extension CustomRealmTBCell {
    public func initializeCell() {
        self.showView.layer.cornerRadius = 16
        self.showView.layer.masksToBounds = true
    }
}
