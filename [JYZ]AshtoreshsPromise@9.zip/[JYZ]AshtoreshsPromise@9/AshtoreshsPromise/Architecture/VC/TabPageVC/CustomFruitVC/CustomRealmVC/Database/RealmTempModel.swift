//
//  RealmTempModel.swift
//  AshtoreshsPromise
//
//  Created by YBTourDev on 5/29/24.
//  Copyright © 2024 이동건. All rights reserved.
//

import Foundation
import RealmSwift

//MARK: - RealmPrimaryModel
class RealmPrimaryModel: Object {
    @Persisted(primaryKey: true) var _id:String
    @Persisted var dataName:String
}
extension RealmPrimaryModel {
}

//MARK: - RealmTempModel
class RealmTempModel: Object {
    @Persisted(primaryKey: true) var compositKey:String = ""
    @Persisted var order:Int = -1
    @Persisted var id:Int = -1
    @Persisted var dataIndex:Int
    @Persisted var dataString: String = ""
    @Persisted var dataList: List<String> = List<String>()
}
extension RealmTempModel {
    public func setUp(_ order:Int, _ id:Int, _ dataIndex:Int, _ dataString:String, _ dataList:List<String>=List<String>()) {
        self.compositKey = self.compositKeyValue()
        self.order = order
        self.id = id
        self.dataIndex = dataIndex
        self.dataString = dataString
        self.dataList = dataList
    }
    public func compositKeyValue() -> String {
        return "\(self.compositKey)\(self.id)"
    }
}
