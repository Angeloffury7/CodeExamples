//
//  CustomRealmVC.swift
//  Sample
//
//  Created by CustomRealmVC on 2021/06/19.
//

import Foundation
import UIKit
import RealmSwift


//MARK: - CustomRealmVC
@available(iOS 15.0, *)
class CustomRealmVC: UIViewController {
    //MARK: - @IBOutlet
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var editButton: UIButton!
    //MARK: - Valueable
    //MARK: Coordinator
    public var coordinator: MoveCoordinator = MoveCoordinator()
    //MARK: RealmDB
    ///public let realmDatabase = try! Realm()
    public let realmTempModel = RealmTempModel()
    public var realmTempOrigin = [RealmTempModel]()
    public var realmTempItem = [RealmTempModel]()
    public let realmTempData = [RealmTempModel]()
    //MARK: - TableView(Component)
    //MARK: FooterView
    public var sectionHeader = ["This is Section Header I",
                                "This is Section Header II",
                                "This is Section Header III"]
    public var sectionFooter = ["This is Section Footer I",
                                "This is Section Footer II",
                                "This is Section Footer III"]
    public let sectionData = [["Cell I", "Cell II", "Cell III"],
                              ["Cell I", "Cell II", "Cell III"],
                              ["Cell I", "Cell II", "Cell III"]]
    public lazy var tbfooterView: UIView = {
        let tbfooterView = UIView()
        self.tbfooterView.backgroundColor = UIColor.gray
        ///self.tbfooterView.frame.height = 1
        return tbfooterView
    }()
    
    
    //MARK: - ViewCycle
    override func viewDidLoad() {
        super.viewDidLoad()
        //MARK: Initialize
        self.tableViewConfigure()
        //MARK: Realm
        ///self.realmConfigure()
        ///self.realmCreate()
        self.realmRead()
    }
    
    //MARK: - @IBAction
    @IBAction func menuButton(_ sender: UIButton) {
        if 0 == sender.tag {
            self.dismiss(animated: true)
        } else if 1 == sender.tag {
            self.tableView.setEditing(!self.tableView.isEditing, animated: true)
            self.editButton.isSelected = !self.tableView.isEditing
            ///self.editButton.isHighlighted = false
            if self.editButton.isSelected {
                self.editButton.setTitleColor(UIColor.white, for: .normal)
                self.editButton.setTitle("Edit", for: .normal)
            } else {
                self.editButton.setTitleColor(UIColor.red, for: .normal)
                self.editButton.setTitle("Done", for: .normal)
            }
        }
    }
}


//MARK: - RealmDB(CRUD)
extension CustomRealmVC {
    public func realmConfigure(){
        self.realmTempItem = Array(RealmDataBaseLib.sharedManager.database.objects(RealmTempModel.self).sorted(byKeyPath: "order",
                                                                                                               ascending: true))
        for item in realmTempItem {
            let newItem = RealmTempModel()
            ///newItem.setUp(item.id, item.kind, item.name)
            self.realmTempItem.append(newItem)
        }
    }
    //MARK: - ReamDB(Create)
    public func realmCreate() {
        //MARK: DataSetting
        ///let realm = try! Realm()
        ///TestModel
        ///let realmTempModel = RealmTempModel()
        //MARK: Realm(Write)
        ///if self.realmDatabase.objects(RealmTempModel.self).isEmpty {
        if RealmDataBaseLib.sharedManager.database.objects(RealmTempModel.self).isEmpty {
            //MARK: Realm(Values)
            do {
                try RealmDataBaseLib.sharedManager.database.write {
                    self.realmTempModel.dataString = "RealmTempModel_dataString(Count:\(RealmDataBaseLib.sharedManager.database.objects(RealmBaseModel.self).count))"
                    RealmDataBaseLib.sharedManager.database.add(self.realmTempModel)
                }
                /**
                //MARK: RealmDB(dataString)
                self.realmTempModel.dataString = "RealmTempModel_dataString(Count:\(self.realmDatabase.objects(RealmBaseModel.self).count))"
                try self.realmDatabase.write {
                    self.realmDatabase.add(self.realmTempModel)
                }
                //MARK: RealmDB(Array)
                let realmTempArray = ["RealmTempModel_00","RealmTempModel_01","RealmTempModel_02"]
                try! self.realmDatabase.write {
                    self.realmTempModel.dataList.append(objectsIn: realmTempArray) ///X
                    self.realmDatabase.add(self.realmTempModel)
                }
                //MARK: RealmDB(Add&Append)
                try! self.realmDatabase.write {
                    print("Realm_Create: \(self.realmTempModel.dataString)")
                    ///Data Add
                    self.realmDatabase.add(self.realmTempModel)
                    ///Data append
                    for index in 0..<realmTempArray.count {
                        self.realmTempModel.dataList.append(realmTempArray[index])
                    }
                }*/
            } catch let error {
                print("Realm_Write(Error): \(error.localizedDescription)")
            }
        } else {
            self.tableView.reloadData()
        }
    }
    //MARK: - ReamDB(Read)
    public func realmRead() {
        ///[Sorted]
        ///self.todoItems = self.selectCategory?.items.sorted(byKeyPath: "title", ascending: true)
        ///[For]
        /**
        for index in 0..<self.realmTempModel.dataList.count {
            print("Realm_DataList: \(self.realmTempModel.dataList[index])")
        }
        for index in 0..<self.realmDatabase.objects(RealmTempModel.self).count {
            print("Realm_Objects: \(self.realmDatabase.objects(RealmTempModel.self)[index].dataString) ")
        }*/
        for index in 0..<RealmDataBaseLib.sharedManager.database.objects(RealmTempModel.self).count {
            print("Realm_dataString: \(RealmDataBaseLib.sharedManager.database.objects(RealmTempModel.self)[index].dataString) ")
        }
        for index in 0..<RealmDataBaseLib.sharedManager.database.objects(RealmTempModel.self).count {
            print("Realm_dataList: \(RealmDataBaseLib.sharedManager.database.objects(RealmTempModel.self)[index].dataList) ")
        }
    }
    //MARK: - ReamDB(Update)
    public func realmUpdate(completion:() -> Void) {
        do {
            try RealmDataBaseLib.sharedManager.database.write {
                completion()
            }
        } catch let error {
            print("Realm_Update: \(error)")
        }
    }
    //MARK: - ReamDB(Delete)
    public func realmDelete(itme: Item) {
        do {
            try RealmDataBaseLib.sharedManager.database.write {
                RealmDataBaseLib.sharedManager.database.delete(itme)
            }
        } catch let error {
            print("Realm_Delete: \(error)")
        }
    }
}


//MARK: - Intialize
extension CustomRealmVC {
    public func tableViewConfigure(){
        //MARK: - Tableview Options
        //MARK: Delegate
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        
        //MARK: AutomaticDimension
        ///self.tableView.estimatedRowHeight = UITableView.automaticDimension
        ///self.tableView.rowHeight = UITableView.automaticDimension
        
        
        //MARK: TopPadding, SetContentOffset, ScrollToRow, leastNormalMagnitude
        self.tableView.sectionHeaderTopPadding = 0
        self.tableView.contentInset = UIEdgeInsets.zero
        //MARK: setContentOffset
        self.tableView.setContentOffset(CGPoint(x: 0, y: self.tableView.contentInset.top), animated: false)
        //MARK: scrollToRow
        let indexPath = IndexPath(row: 0, section: 0)
        self.tableView.scrollToRow(at: indexPath, at: .top, animated: false)
        
        
        //MARK: leastNormalMagnitude
        self.tableView.tableHeaderView = UIView(frame: CGRect(origin: .zero,
                                                              size: CGSize(width:CGFloat.leastNormalMagnitude,
                                                                           height: CGFloat.leastNormalMagnitude)))
        self.tableView.tableFooterView = UIView(frame: CGRect(origin: .zero,
                                                              size: CGSize(width:CGFloat.leastNormalMagnitude,
                                                                           height: CGFloat.leastNormalMagnitude)))
        
        
        //MARK: - Group Style(Remove space between header/Footer sections
        self.tableView.tableHeaderView = UIView(frame: CGRect(origin: .zero,
                                                              size: CGSize(width:CGFloat.leastNormalMagnitude,
                                                                           height: CGFloat.leastNormalMagnitude)))
        self.tableView.tableFooterView =
        UIView(frame: CGRect(origin: .zero,
                             size: CGSize(width:CGFloat.leastNormalMagnitude,
                                          height: CGFloat.leastNormalMagnitude)))
        
        
        //MARK: - Tableview Setting
        //MARK: Header
        let header = UIView(frame: CGRect(x: 0,
                                          y: 0,
                                          width: self.view.frame.size.width,
                                          height: self.view.frame.size.height / 5.8))
        header.backgroundColor = .black
        let headerLabel = UILabel(frame: header.bounds)
        headerLabel.text = "This is tableView Header"
        headerLabel.textColor = .white
        headerLabel.textAlignment = .center
        header.addSubview(headerLabel)
        self.tableView.tableHeaderView = header
        //MARK: Footer
        let footer = UIView(frame: CGRect(x: 0,
                                          y: 0,
                                          width: self.view.frame.size.width,
                                          height: self.view.frame.size.height / 5.8))
        footer.backgroundColor = .systemGray5
        let footerLabel = UILabel(frame: footer.bounds)
        footerLabel.text = "This is tableView Footer"
        footerLabel.textColor = .black
        footerLabel.textAlignment = .center
        footer.addSubview(footerLabel)
        self.tableView.tableFooterView = footer
    }
}


//MARK: - UITableView Delegate
@available(iOS 15.0, *)
extension CustomRealmVC: UITableViewDelegate, UITableViewDataSource {
    //MARK: EditForInSection
    public func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    ///아래 두 메서드는 editing mode로 전환되었을 때 cell 앞 부분의 delete button이 뜨지 않게 해 줍니다.
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        ///return .none
        return .delete
    }
    func tableView(_ tableView: UITableView, shouldIndentWhileEditingRowAt indexPath: IndexPath) -> Bool {
        ///return false
        return true
    }
    public func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            ///self.itemName.remove(at: indexPath.row)
            do {
                try RealmDataBaseLib.sharedManager.database.write {
                    ///self.realmTempModel.dataString = "RealmTableData"
                    RealmDataBaseLib.sharedManager.database.objects(RealmTempModel.self).first!.dataList.remove(at: indexPath.row)
                }
            } catch let error {
                print("Realm_Delete: \(error)")
            }
            ///tableView.deleteRows(at: [indexPath], with: .fade)
            self.tableView.reloadData()
        } else if editingStyle == .insert {
            ///Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view.
        } else {
            ///self.testData.insert(self.testData[indexPath.row], at: indexPath.row + 1)
            ///self.tableView.insertRows(at: [indexPath], with: .automatic)
        }
    }
    
    
    //MARK: SwipeActions
    func tableView(_ tableView: UITableView,
                   leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let action = UIContextualAction(style: .normal,
                                        title: "Favourite") { [weak self] (action, view, completionHandler) in
                                                self?.handleMarkAsFavourite()
                                                completionHandler(true)
        }
        action.backgroundColor = UIColor.blue
        return UISwipeActionsConfiguration(actions: [action])
    }
    private func handleMarkAsFavourite() {
        print("Marked as favourite")
    }
    
    
    
    //MARK: NumberOfSections
    func numberOfSections(in tableView: UITableView) -> Int {
        ///return self.sectionData.count
        return ((RealmDataBaseLib.sharedManager.database.objects(RealmTempModel.self).first?.dataList.isEmpty) != nil) ? 1 : 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        ///return self.sectionData[section].count
        ///print("RealmDB(COunt):\(self.realmDatabase.objects(RealmTempModel.self).count)")
        ///print("RealmDB(DataList):\(self.realmDatabase.objects(RealmTempModel.self)[0].dataList)")
        print("RealmDB_Count:(\(String(describing: RealmDataBaseLib.sharedManager.database.objects(RealmTempModel.self).first?.dataList.count)))")
        return ((RealmDataBaseLib.sharedManager.database.objects(RealmTempModel.self).first?.dataList.isEmpty) != nil)
                ? (RealmDataBaseLib.sharedManager.database.objects(RealmTempModel.self).first?.dataList.count)! : 1
    }

    
    //MARK: HeightForInSection
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        ///Group Style: Remove space between header sections
        ///return .leastNormalMagnitude
        return CGFloat(40)
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        ///Group Style: Remove space between footer sections
        ///return .leastNormalMagnitude
        return CGFloat(40)
    }

    
    /**
    MARK: TitleForInSection
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        ///return nil
        return self.sectionHeader[section]
    }

    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        ///return nil
        return self.sectionFooter[section]
    } */
    
    /**
    //MARK: ViewForInSection
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        ///let header = UIView()
        ///header.backgroundColor = .systemOrange
        ///return header
        let cell = tableView.dequeueReusableCell(withIdentifier: "CustomCell")!
        cell.backgroundColor = UIColor.darkGray
        cell.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        cell.layer.cornerRadius = 0
        cell.layer.masksToBounds = true
        cell.textLabel?.textColor = UIColor.white
        cell.textLabel?.text = self.sectionHeader[section]
        return cell
    }
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        ///let footer = UIView()
        ///footer.backgroundColor = .systemYellow
        ///return footer
        let cell = tableView.dequeueReusableCell(withIdentifier: "CustomCell")!
        cell.backgroundColor = UIColor.lightGray
        cell.layer.maskedCorners = [.layerMinXMaxYCorner, .layerMaxXMaxYCorner]
        cell.layer.cornerRadius = 0
        cell.layer.masksToBounds = true
        cell.textLabel?.textColor = UIColor.white
        cell.textLabel?.text = self.sectionFooter[section]
        return cell
    }*/
    

    //MARK: HeightForRowAt indexPath
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        ///return UITableView.automaticDimension
        return 30
    }
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        ///return UITableView.automaticDimension
        return 0
    }
    
    
    //MARK: CellForRowAt IndexPath
    //지금상황은( 난 내 의견만 표출
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "CustomCell")!
        ///cell.selectionStyle = UITableViewCell.SelectionStyle.none
        ///cell.selectionStyle = .none
        ///cell.contentView.frame.inset(by: UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0))
        cell.backgroundColor = UIColor.white
        cell.textLabel?.textColor = .black
        ///cell.textLabel?.text = self.sectionData[indexPath.section][indexPath.row]
        cell.textLabel?.text = ((RealmDataBaseLib.sharedManager.database.objects(RealmTempModel.self).first?.dataList.isEmpty) != nil)
                                ? RealmDataBaseLib.sharedManager.database.objects(RealmTempModel.self).first!.dataList[indexPath.row] 
                                : "RealmTempModel_isEmpty"
        return cell
    }
    
    
    //MARK: didSelectRowAt IndexPath
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("didSelectRowAt:\(indexPath.row)")
        ///MARK: TableView(Refresh)
        ///self.tableView.reloadData()
        ///self.tableView.beginUpdates()
        ///self.tableView.setNeedsDisplay()
        ///self.tableView.endUpdates()
        ///self.tableView?.reloadRows(at: [IndexPath(item: 1, section: 2), IndexPath(item: 4, section: 3)], with: .none)
        ///self.tableView.reloadRows(at: [IndexPath(row: 0, section: 3)], with: .none)
        ///self.tableView.reloadSections(IndexSet(0...3), with: .none)
        ///self.tableView.reloadSections(IndexSet(integer: 3), with: .automatic)
    }
    
    
    //MARK: MoveRowAt IndexPath
    /**
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        guard sourceIndexPath != destinationIndexPath else { return }
        ///let item = tempListItems[sourceIndexPath.row]
        let realmTempItem = RealmDataBaseLib.sharedManager.database.objects(RealmTempModel.self).first!.dataList[sourceIndexPath.row]
        ///self.tempListItems.remove(at: sourceIndexPath.row)
        RealmDataBaseLib.sharedManager.database.objects(RealmTempModel.self).first!.dataList.remove(at: sourceIndexPath.row)
        ///self.tempListItems.insert(item, at: destinationIndexPath.row)
        RealmDataBaseLib.sharedManager.database.objects(RealmTempModel.self).first!.dataList.insert(realmTempItem, at: destinationIndexPath.row)
        
        //for index in 0..<(RealmDataBaseLib.sharedManager.database.objects(RealmTempModel.self).first?.dataList.count)! {
        //    RealmDataBaseLib.sharedManager.database.objects(RealmTempModel.self).first!.dataList[index].order = index
        //}
        self.tableView.reloadData()
    }*/
    ///테이블 뷰의 행의 순서를 바꿀 수 있는 버튼과, 버튼을 드래그 드롭해서 순서를 바꿀 수 있게 하는 메서드입니다.
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        ///dataSource의 순서를 바꿔주는 메서드입니다. 처음 드래그 했던 행과 드롭하는 위치에 있는 행의 데이터의 순서를 바꿉니다. 
        ///이 코드를 작성하지 않아도 행 간의 위치는 바꿀 수 있었지만, 바꿀 때 데이터가 중복이 되는 형상이 일어나는 경우가 있었습니다.
        ///let moveCell = self.list[sourceIndexPath.row]
        ///self.list.remove(at: sourceIndexPath.row)
        ///self.list.insert(moveCell, at: destinationIndexPath.row)
        let moveCell = RealmDataBaseLib.sharedManager.database.objects(RealmTempModel.self).first!.dataList[sourceIndexPath.row]
        ///RealmDataBaseLib.sharedManager.database.objects(RealmTempModel.self).first!.dataList.remove(at: sourceIndexPath.row)
        RealmDataBaseLib.sharedManager.database.objects(RealmTempModel.self).first!.dataList.insert(moveCell, at: destinationIndexPath.row)
    }
}
