//
//  Contact.swift
//  Expandable TableView
//
//  Created by Mohamed Elbana on 11/21/19.
//  Copyright © 2019 Mohamed Elbana. All rights reserved.
//

import Foundation

struct Contact {
    var name: String
    var phone: String
}
