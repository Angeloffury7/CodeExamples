//
//  ViewController.swift
//  Expandable TableView
//
//  Created by Mohamed Elbana on 11/21/19.
//  Copyright © 2019 Mohamed Elbana. All rights reserved.
//

import UIKit

class CustomTableVC: UIViewController {
    //MARK: - @IBoutlet
    @IBOutlet weak var tableView: UITableView!

    
    //MARK: - Variables
    ///PageVIew
    public var pageIndex: Int!
    ///TableView
    public var tableViewData: [Group] = []
    public var selectedData = [IndexPath]()


    //MARK: - ViewLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        self.initDummyData()
        self.initTableView()
    }
}



//MARK: - @IBAction
extension CustomTableVC {
    @IBAction func tableCellMenuButton(_ sender: UIButton) {
        if sender.tag == 0{
            let editing = tableView.isEditing
            self.tableView.setEditing(!editing, animated: true)
        } else if sender.tag == 1 {
            self.tableView.beginUpdates()
            self.tableView.reloadRows(at: selectedData, with: .automatic)
            self.tableView.endUpdates()
            for item in selectedData {
                self.tableView.selectRow(at: item, animated: false, scrollPosition: .none)
            }
        }
    }
}

//MARK: - Initialize
extension CustomTableVC {
    public func initDummyData() {
        self.tableViewData = [
            Group(title: "Family",
                  contacts: [Contact(name: "Contact 1", phone: "+20 123 456 7788"),
                             Contact(name: "Contact 2", phone: "+20 123 456 7788")]
                 ),
            Group(title: "Friends",
                  contacts: [Contact(name: "Contact 3", phone: "+20 123 456 7788"),
                             Contact(name: "Contact 4", phone: "+20 123 456 7788")]
                 ),
            Group(title: "Work",
                  contacts: [Contact(name: "Contact 5", phone: "+20 123 456 7788"),
                             Contact(name: "Contact 6", phone: "+20 123 456 7788"),
                             Contact(name: "Contact 7", phone: "+20 123 456 7788")]
                 ),
            Group(title: "School",
                  contacts: [Contact(name: "Contact 8", phone: "+20 123 456 7788"),
                             Contact(name: "Contact 9", phone: "+20 123 456 7788"),
                             Contact(name: "Contact 10", phone: "+20 123 456 7788")]
                 )]
    }
}


//MARK: - UITableViewDelegate
extension CustomTableVC: UITableViewDelegate {
    func initTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: "ContactCell", bundle: nil), forCellReuseIdentifier: "ContactCell")
        tableView.register(UINib(nibName: "GroupCell", bundle: nil), forCellReuseIdentifier: "GroupCell")
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        tableViewData.count
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableViewData[section].isOpen {
            return tableViewData[section].contacts.count + 1
        } else {
            return 1
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: "GroupCell", for: indexPath) as! GroupCell
            cell.initCell(tableViewData[indexPath.section].title, tableViewData[indexPath.section].contacts.count)
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "ContactCell", for: indexPath) as! ContactCell
        cell.initCell(tableViewData[indexPath.section].contacts[indexPath.row - 1])
            return cell
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.row == 0 {
            if tableViewData[indexPath.section].isOpen {
                tableViewData[indexPath.section].isOpen = false
            } else {
                tableViewData[indexPath.section].isOpen = true
            }
            reloadSections(indexPath: indexPath)
        }
    }
    func tableView(_ tableView: UITableView, didDeselectRowAt indexPath: IndexPath) {
    }
    func reloadSections(indexPath: IndexPath) {
        let sections = IndexSet.init(integer: indexPath.section)
        tableView.reloadSections(sections, with: .none)
    }
}


extension CustomTableVC: UITableViewDataSource {
    func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    func tableView(_ tableView: UITableView, moveRowAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        /**
        let movedObject = self.headlines[sourceIndexPath.row]
        headlines.remove(at: sourceIndexPath.row)
        headlines.insert(movedObject, at: destinationIndexPath.row)
        debugPrint("\(sourceIndexPath.row) => \(destinationIndexPath.row)")
        // To check for correctness enable: self.tableView.reloadData()
         */
    }
}

