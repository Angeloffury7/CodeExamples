//
//  ViewController.swift
//  collectionViewCustomHeaderDemo
//
//  Created by MacMini on 5/9/19.
//  Copyright © 2019 Immanent. All rights reserved.
//

import UIKit
import RxSwift
import RxCocoa
import Combine
import Moya


class CustomMainVC: UIViewController {
    //MARK: - @IBOutlet
    @IBOutlet weak var demoTableView: UITableView!
    @IBOutlet weak var datetimeLabel: UILabel!
    
    
    //MARK: - Variables
    //MARK: Swift
    public let customBaseVM = BaseViewModel.sharedManager
    //MARK: ReativeX
    public let disposeBag = DisposeBag()
    //MARK: Combine
    private var anyCancellable: Set<AnyCancellable> = []
    //MARK: DummyData
    public var pageIndex: Int!
    public let imageArray = ["ImgVewCC_00.jpeg","ImgVewCC_01.jpeg","ImgVewCC_02.jpeg",
                             "ImgVewCC_03.jpeg","ImgVewCC_04.jpeg","ImgVewCC_05.jpeg",
                             "ImgVewCC_06.jpeg","ImgVewCC_07.jpeg","ImgVewCC_08.jpeg",
                             "ImgVewCC_09.jpeg"]
    public let tempData = ["tempData 0","tempData 1","tempData 2","tempData 3",
                           "tempData 4","tempData 5","tempData 6","tempData 7",
                           "tempData 8","tempData 9","tempData 10","tempData 11"]
    
    //MARK: - ViewLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        //MARK: Initialize(VC+Binding)
        self.InitializeVC()
        ///self.dataBindingReactiveX()
        self.dataBindingObservable()
        ///self.dataBindingAFCombine()
    }
}

extension CustomMainVC {
    //MARK: ViewController(DataValue)
    public func InitializeVC(){
        self.demoTableView.estimatedRowHeight = 281.5
        self.demoTableView.rowHeight = UITableViewAutomaticDimension
    }
    //MARK: - DataBinding
    //MARK: ViewModel(ReactiveX)
    public func dataBindingReactiveX(){
        self.customBaseVM.reativeXData
            .bind(to: self.datetimeLabel.rx.text)
            .disposed(by: disposeBag)
        ///self.customBaseVM.reload()
        ///print("dataBinding_ReactiveX:\(String(describing: self.dateTimeVM.dateTimeString.value))")
    }
    //MARK: ViewModel(Observable)
    public func dataBindingObservable(){
        self.customBaseVM.observableData.bind { result in
            if result!.isEmpty {
                ///self.customTableVM.getDateData()
            } else {
                ///print("dataBinding_Observable:\(String(describing: self.customTableVM.dateString.value ?? nil))")
                ///self.datetimeLabel.text = self.customTableVM.dateString.value
            }
        }
    }
    //MARK: ViewModel(AFCombine)
    public func dataBindingAFCombine(){
        /**
        let url = "http://worldclockapi.com/api/json/utc/now"
        BaseNetworkLibrary.baseAFCombine(URL.getCommonUrl(url)!)
            .decode(type: UtcTimeModel.self, decoder: JSONDecoder())
            .map { $0.currentDateTime }
            .handleEvents(receiveSubscription: { _ in print("Subscribed") },
                          receiveOutput: { _ in print("Received")},
                          receiveCompletion: { _ in print("Completed") },
                          receiveCancel: { print("Canceled") },
                          receiveRequest: {_ in print("Requested") })
            .sink { completion in
                print("dataBindingCombine_Completion:\(completion)")
            } receiveValue: { value in
                print("dataBindingCombine_Value:\(String(describing: value))")
            }.store(in: &anyCancellable)
         */
        self.customBaseVM.AFCombineReload()
        self.customBaseVM.$afCombineData
            .map { $0 as String? }
            .debounce(for: 0.0, scheduler: RunLoop.main)
            .removeDuplicates()
            .assign(to: \.self.datetimeLabel.text, on: self)
            .store(in: &anyCancellable)
    }
}


//MARK: - UITableViewDelegate
extension CustomMainVC: UITableViewDataSource,UITableViewDelegate {
    func numberOfSections(in tableView: UITableView) -> Int {
        if tableView == demoTableView {
            return 2
        }else {
            return 1
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 1 {
            return 1
        }else{
            return 1
        }
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        switch indexPath.section {
        case 0:
            return 300
        case 1:
            return 190
        default:
            return 300
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell1 = tableView.dequeueReusableCell(withIdentifier: "CATableViewCell", for: indexPath) as! CATableViewCell
            cell1.testLabel.text = "CATableViewCell"
            return cell1
        } else {
            let cell2 = tableView.dequeueReusableCell(withIdentifier: "CBTableViewCell", for: indexPath) as! CBTableViewCell
            cell2.ccollectionView.delegate = self
            cell2.ccollectionView.dataSource = self
            ///var height = cell2.testCollectionView.collectionViewLayout.collectionViewContentSize.height
            ///cell2.heightContraint.constant = height
            self.view.layoutIfNeeded()
            return cell2
        }
    }
}

//MARK: - UICollectionViewDelegate
extension CustomMainVC: UICollectionViewDelegate, UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.imageArray.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell3 = collectionView.dequeueReusableCell(withReuseIdentifier: "CCollectionViewCell", for: indexPath) as! CCollectionViewCell
        cell3.imageTest.image = UIImage(named: self.imageArray[indexPath.row])
        cell3.imageTest.contentMode = UIView.ContentMode.scaleToFill
        return cell3
    }
    /**
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if kind == UICollectionView.elementKindSectionHeader
        {
            let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "headerView", for: indexPath)
            return headerView
        }
        return UICollectionReusableView()
    }*/
}
class DynamicCollectionView: UICollectionView {
    override func layoutSubviews() {
        super.layoutSubviews()
        if bounds.size != intrinsicContentSize {
            invalidateIntrinsicContentSize()
        }
    }
    override var intrinsicContentSize: CGSize {
        return self.contentSize
    }
}
