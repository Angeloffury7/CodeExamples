//
//  testTableViewCell.swift
//  collectionViewCustomHeaderDemo
//
//  Created by MacMini on 5/15/19.
//  Copyright © 2019 Immanent. All rights reserved.
//

import UIKit
import ImageSlideshow

class CATableViewCell: UITableViewCell, ImageSlideshowDelegate {

    //MARK: @IBOutlet
    @IBOutlet var testLabel:UILabel!
    @IBOutlet weak var imageSlideView: ImageSlideshow!
    
    //MARK: ImageSOurce
    public let localSource = [BundleImageSource(imageString: "ImageSlide1"),
                              BundleImageSource(imageString: "ImageSlide2"),
                              BundleImageSource(imageString: "ImageSlide3"),
                              BundleImageSource(imageString: "ImageSlide4")]
    public let alamofireSource = [AlamofireSource(urlString: "https://images.unsplash.com/photo-1432679963831-2dab49187847?w=1080")!,
                                  AlamofireSource(urlString: "https://images.unsplash.com/photo-1447746249824-4be4e1b76d66?w=1080")!,
                                  AlamofireSource(urlString: "https://images.unsplash.com/photo-1463595373836-6e0b0a8ee322?w=1080")!]
    //MARK: Initialize
    override func awakeFromNib() {
        super.awakeFromNib()
        ///Initialization code
        self.setImageSlide()
    }
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        //Configure the view for the selected state
    }
}

extension CATableViewCell {
    public func setImageSlide() {
        self.imageSlideView.slideshowInterval = 5.0
        self.imageSlideView.pageIndicatorPosition = .init(horizontal: .center, vertical: .bottom)
        self.imageSlideView.contentScaleMode = UIViewContentMode.scaleToFill
        ///self.imageSlideView.pageIndicator = UIPageControl.withSlideshowColors()
        ///optional way to show activity indicator during image load (skipping the line will show no activity indicator)
        self.imageSlideView.activityIndicator = DefaultActivityIndicator()
        self.imageSlideView.delegate = self
        ///can be used with other sample sources as `afNetworkingSource`, `alamofireSource` or `sdWebImageSource` or `kingfisherSource`
        DispatchQueue.global(qos: .userInitiated).async {
            DispatchQueue.main.async {
                if !self.alamofireSource.isEmpty {
                    self.imageSlideView.setImageInputs(self.localSource)
                } else {
                    
                }
            }
        }
        ///self.imageSlideView.setImageInputs(self.alamofireSource)
        ///self.imageSlideView.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(ViewController.didTap)))
    }
}
