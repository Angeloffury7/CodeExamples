//
//  BaseViewModel.swift
//  AnnabelleSapphire
//
//  Created by YBTourDev on 5/16/24.
//  Copyright © 2024 이동건. All rights reserved.
//

import Foundation
import RxRelay

//MARK: - BaseViewModel(Class)
class BaseViewModel {
    //MARK: DesignPTN(SingleTon)
    public static let sharedManager = BaseViewModel()
    //MARK: CustomTableVM(Observable)
    public let observableData: Observable<String?> = Observable("")
    //MARK: DateTimeVM(ReactiveX)
    public let reativeXData = BehaviorRelay(value: "Loading..")
    //MARK: BaseViewModel(Combine)
    @Published public var afCombineData:String? = "Loading.."
    public var moyaDefaultData:String? = "Loading.."
    @Published public var moyaCombineData:String? = "Loading.."
    //MARK: MoyaViewModel(Countiation)
    public var moyaCountiationData:String? = "Loading.."
}
//MARK: - BaseViewModel(Extension)
extension BaseViewModel {
    public static func dateToString(date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy년 MM월 dd일 HH시 mm분"
        return formatter.string(from: date)
    }
}
//MARK: - BaseViewModel(DataBinding)
extension BaseViewModel {
    public func getObservableData() {
        BaseServiceAPI.CustomAlamofireService { [self] model in  ///{ [weak self] model in
            ///guard let self = self else { return }
            self.observableData.value = BaseViewModel.dateToString(date: model.currentDateTime)
        }
    }
    //MARK: DateTimeVM(ReactiveX)
    public func URLSessionReload() {
        BaseServiceAPI.CustomAlamofireService { [self] model in ///{ [weak self] model in
            ///guard let self = self else { return }
            self.reativeXData.accept(BaseViewModel.dateToString(date: model.currentDateTime))
        }
    }
    //MARK: CustomTableVM(Observable)
    public func AlamofireReload() {
        BaseServiceAPI.CustomAFCombineService { [self] model in  ///{ [weak self] model in
            ///guard let self = self else { return }
            self.observableData.value = BaseViewModel.dateToString(date: model.currentDateTime)
        }
    }
    //MARK: BaseViewModel(AFCombine)
    public func AFCombineReload() {
        BaseServiceAPI.CustomAFCombineService { [self] model in ///{ [weak self] model in
            ///guard let self = self else { return }
            self.afCombineData = BaseViewModel.dateToString(date: model.currentDateTime)
        }
    }
    //MARK: BaseViewModel(Countination)
    public func MoyaCountinationReload() async {
        await BaseServiceAPI.CustomMoyaCountinationService { [self] model in ///{ [weak self] model in
            ///guard let self = self else { return }
            self.moyaCountiationData = BaseViewModel.dateToString(date: model.currentDateTime)
        }
    }
}
