//
//  Observable.swift
//  TalkTalkNY
//
//  Created by HanilNW on 2023/06/19.
//


import Foundation


class Observable<T> {
    typealias Listener = (T) -> Void
    private var listener: Listener?
    public var value: T {
       didSet {
           self.listener?(value)
       }
    }
    init(_ value: T) {
        self.value = value
    }
}
extension Observable {
    public func bind(_ listener: Listener?) {
        self.listener = listener
        listener?(value)
    }
    public func removeObservable() {
        self.listener = nil
    }
}
