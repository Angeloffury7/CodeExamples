//
//  KeyChainToken.swift
//  SampleSource
//
//  Created by HanilNW on 2023/07/18.
//

import Foundation
import Security
import Alamofire


class KeyChainToken {
    static public func create(_ accessToken:String="", _ refreshToken:String="") -> Bool {
        let accessTokenQuery: NSDictionary = [
            kSecClass : kSecClassGenericPassword,
            kSecAttrService: authURL,
            kSecAttrAccount: "accessToken",
            kSecValueData: accessToken.data(using: .utf8, allowLossyConversion: false)!
        ]
        let refreshTokenQuery: NSDictionary = [
            kSecClass : kSecClassGenericPassword,
            kSecAttrService: authURL,
            kSecAttrAccount: "refreshToken",
            kSecValueData: refreshToken.data(using: .utf8, allowLossyConversion: false)!
        ]
        SecItemDelete(accessTokenQuery)
        SecItemDelete(refreshTokenQuery)
        if let accessTokenQuery = SecItemAdd(accessTokenQuery, nil) as OSStatus?,
           let refreshTokenQuery = SecItemAdd(refreshTokenQuery, nil) as OSStatus? {
            assert(accessTokenQuery == noErr, "failed to saving accessTokenQuery")
            assert(refreshTokenQuery == noErr, "failed to saving refreshTokenQuery")
            return true
        } else {
            return false
        }
    }
    
    static public func read(_ account: String = "") -> String? {
        let KeyChainQuery: NSDictionary = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: authURL,
            kSecAttrAccount: account,
            kSecReturnData: kCFBooleanTrue as Any,
            kSecMatchLimit: kSecMatchLimitOne
        ]
        var dataTypeRef: AnyObject?
        let status = SecItemCopyMatching(KeyChainQuery, &dataTypeRef)
        if(status == errSecSuccess) {
            let retrievedData = dataTypeRef as! Data
            let value = String(data: retrievedData, encoding: String.Encoding.utf8)
            return value
        } else {
            print("failed to loading, status code = \(status)")
            return nil
        }
    }
    
    static public func delete(_ service: String, account: String) {
        let keyChainQuery: NSDictionary = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: service,
            kSecAttrAccount: account
        ]
        let status = SecItemDelete(keyChainQuery)
        assert(status == noErr, "failed to delete the value, status code = \(status)")
    }
      
    static public func getAuthorizationHeader() -> HTTPHeaders? {
        if let accessToken = self.read("accessToken") {
            return ["Authorization":"Bearer \(accessToken)"] as HTTPHeaders
        } else {
            return nil
        }
    }
        
    static public func logout(completion:(Bool)->()) {
        KeyChainToken.delete(authURL, account: "accessToken")
        KeyChainToken.delete(authURL, account: "refreshToken")
        completion(true)
    }
}
