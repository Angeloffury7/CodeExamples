//
//  KeychainInterceptor.swift
//  TalkTalkNY
//
//  Created by HanilNW on 2023/07/21.
//

import UIKit
import Alamofire

final class KeyReqInterceptor: RequestInterceptor {
    func adapt(_ urlRequest: URLRequest, for session: Session, completion: @escaping (Result<URLRequest, Error>) -> Void) {
        guard urlRequest.url?.absoluteString.hasPrefix(authURL) == true,
              case let accessToken = KeyChainToken.read("accessToken") else {
            completion(.success(urlRequest))
            return
        }
        guard urlRequest.url?.absoluteString.hasPrefix(serverURL) == true,
              case accessToken = KeyChainToken.read("accessToken") else {
            completion(.success(urlRequest))
            return
        }
        var urlRequest = urlRequest
        urlRequest.setValue("Bearer " + accessToken!, forHTTPHeaderField:"Authorization")
        completion(.success(urlRequest))
    }
    func retry(_ request: Request, for session: Session, dueTo error: Error, completion: @escaping (RetryResult) -> Void) {
        guard let response = request.task?.response as? HTTPURLResponse, response.statusCode == 401 else {
            completion(.doNotRetryWithError(error))
            return
        }
        if let refreshToken = KeyChainToken.read("refreshToken"), !refreshToken.isEmpty, refreshToken.count > 0 {
            TokenAPI.tokenRefresh(refreshToken:refreshToken){ result in
                switch result{
                case .success(let data):
                    guard KeyChainToken.create(data.access_token!, data.refresh_token!) else { return }
                    completion(.retry)
                    break
                case .failure(_):
                    completion(.doNotRetryWithError(error))
                    break
                }
            }
        } else {
            completion(.doNotRetryWithError(error))
            return
        }
    }
}
