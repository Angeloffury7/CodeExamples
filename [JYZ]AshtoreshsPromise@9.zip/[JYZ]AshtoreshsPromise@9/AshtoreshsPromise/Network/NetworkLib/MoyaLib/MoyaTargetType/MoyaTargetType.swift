//
//  APITarget.swift
//  YBTour
//
//  Created by FOCUSONE Inc. on 2023/11/28.
//

import Foundation
import Moya


//MARK: - MoyaAPIError
enum MoyaAPIError: Error {
    case decodeError                    // response 디코딩 에러
    case serverError                    // 서버 에러
    case requestError                   // request 에러
    case networkError                   // 네트워크 에러
    case unknown(message: String)       // 그 외 에러
    
    var errorDescription: String {
        switch self {
        case .decodeError:              return "response 디코딩 실패"
        case .serverError:              return "서버 에러"
        case .requestError:         	return "API Request 에러"
        case .networkError:             return "네트워크 에러"
        case .unknown(let message):     return message
        }
    }
}


//MARK: - BaseTargetType
protocol BaseTargetType: TargetType {}
extension BaseTargetType {
    var method: Moya.Method {
        return .post
    }
    var headers: [String : String]? {
        return ["Content-Type": "application/json"]
    }
    var validationType: ValidationType {
        return .successCodes
    }
}
struct PushInfoAgreeDTO: Encodable {
    var pushSeq: String
    var infoAgreeYn: String
}
struct PushADAgreeDTO: Encodable {
    var pushSeq: String
    var adAgreeYn: String
}
struct RegPushDTO: Encodable {
    var pushToken: String
    var appDiv: String
    var osType: String
    var noIndicator: String
}


//MARK: - CombineMoyaTarget
enum MoyaTargetType{
    case requesTarget
}
extension MoyaTargetType: Moya.TargetType {
    public var baseURL: URL{
        switch self{
        case .requesTarget:
            return URL(string: "http://worldclockapi.com/api/json/utc/now")!
        }
    }
    public var path: String {
        switch self {
        case .requesTarget:
            return ""
        }
    }
    public var method: Moya.Method {
        switch self {
        case .requesTarget:
            return .get
        }
    }
    public var sampleData: Data {
        return Data()
    }
    public var task: Moya.Task {
        switch self {
        case .requesTarget:
            /**
            var params: [String: Any] = [:]
            params["action"] = "get_standings"
            params["league_id"] = 152
            params["APIkey"] = "fb3816f9f0f2efe99d043b02e3ba5ca263c2b8cda14e98afd7f8f76df4d7a129"
            return .requestParameters(parameters: params, encoding: URLEncoding.default)
             */
            ///requestParameters(parameters: [:], encoding: URLEncoding.default)
            ///.requestJSONEncodable(UtcTimeModel.self as! Encodable)
            return .requestPlain
        }
    }
    public var headers: [String : String]? {
        var header:[String:String] = [:]
        switch self {
        default:
            header["Content-Type"] = "application/json"
        }
        return header
    }
}

//MARK: - AJAXAPITarget
///AJAX API
enum AJAXAPITarget {
    case modPushInfoAgree(dto: PushInfoAgreeDTO)                     // 푸시 수신 동의처리
    case modPushADAgree(dto: PushADAgreeDTO)                         // 광고 수신 동의 처리
    case pushAgreeInfo(pushSeq: String)                              // 푸시 동의 정보 가져오기
    case regPush(dto: RegPushDTO)                                    //
    case updateVersion                                               // 버전체크
}

extension AJAXAPITarget: BaseTargetType {
    var baseURL: URL {
        switch self {
        case .modPushInfoAgree,
                .modPushADAgree,
                .pushAgreeInfo,
                .regPush:                   return URL(string: "\(MoyaConstant.serverURL)/common/push")!
        default:                            return URL(string: MoyaConstant.serverURL)!
        }
    }
    
    var path: String {
        switch self {
        case .modPushADAgree:               return "modPushADAgree.ajax"
        case .modPushInfoAgree:             return "modPushInfoAgree.ajax"
        case .pushAgreeInfo:                return "getPushAgreeInfo.ajax"
        case .regPush:                      return "regPush.ajax"
        case .updateVersion:                return "/rest/app/getUpdateVersion.ajax"
        }
    }
    
    var task: Moya.Task {
        switch self {
        case .modPushInfoAgree(let dto):    return .requestJSONEncodable(dto)
        case .modPushADAgree(let dto):      return .requestJSONEncodable(dto)
        case .pushAgreeInfo(let pushSeq):   return .requestParameters(
            parameters: [
                "pushSeq": pushSeq
            ],
            encoding: JSONEncoding.prettyPrinted
        )
        case .regPush(let dto):             return .requestJSONEncodable(dto)
        case .updateVersion:                return .requestParameters(
            parameters: [
                "osType": "iOS",
                "appType" : "TOUR"
            ],
            encoding: URLEncoding.queryString
        )
        }
    }
}


//MARK: - RESTAPITarget
struct RestfulApiDTO: Encodable {
    var uid: String
    var upw: String
    var autoSignIn: String
    var channelCode: String
    var returnUrl: String
}
enum RESTAPITarget {
    case login(dto: RestfulApiDTO)                                        // 유저 이메일 로그인
    case updateToken(ybaskey: String)                                // YBSSTK 토큰 업데이트
    case getAutoLoginToken                                           // YBASKEY 발급
    case getUser                                                     // 사용자 정보 발급
}
extension RESTAPITarget: BaseTargetType {
    var baseURL: URL {
        return URL(string: MoyaConstant.loginServerURL)!
    }
    var path: String {
        switch self {
        case .login:                        return "api/login"
        case .updateToken:              	return "api/signin/token/issued"
        case .getAutoLoginToken:        	return "api/signin/ybaskey/issued"
        case .getUser:               		return "api/signin/user"
        }
    }
    var task: Moya.Task {
        switch self {
        case .login(let dto):
            return .requestJSONEncodable(dto)
        case .updateToken(let ybaskey):
            return .requestParameters(
                parameters: [
                    "ybaskey": ybaskey
                ],
                encoding: JSONEncoding.prettyPrinted
            )
        default:
            return .requestPlain
        }
    }
    var method: Moya.Method {
        switch self {
        case .getUser:
            return .get
        default:
            return .post
        }
    }
    var headers: [String : String]? {
        var header = [
            "Content-Type": "application/json",
        ]
        switch self {
        case .login,
                .getUser,
                .getAutoLoginToken:
            // 자동 로그인 토큰 값이 있을 경우 쿠키 삽입
            ///if !PreferenceManager.shared.ybsstk.isEmpty {
            ///    header["Cookie"] = "_YBSSTK=\(PreferenceManager.shared.ybsstk)"
            ///}
            return header
            
        default:
            return header
        }
    }
}
