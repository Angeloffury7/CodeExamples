//
//  MoyaLoggingPlugIn.swift
//  YBTour
//
//  Created by FOCUSONE Inc. on 2023/11/28.
//

import Foundation
import Moya
import UIKit

/// API 로그를 보기 위한 클래스 입니다
final class MoyaLoggingPlugIn: PluginType {
    func willSend(_ request: RequestType, target: TargetType) {
        print("""
        ===============================================================
        - 🛰️ [REQUEST] >>
        - [URL]:  \(request.request?.url?.absoluteString ?? "__none__")
        - [TIME]: \(Date().debugDescription)
        - [METHOD]: \(request.request?.method ?? .post)
        - [HEADER]: \(request.request?.allHTTPHeaderFields ?? [:])
        - [PARAMETER]: \(String(data: request.request?.httpBody ?? Data(), encoding: .utf8) ?? "__none__")
        ===============================================================
        """)
    }
    
    func didReceive(_ result: Result<Response, MoyaError>, target: TargetType) {
        switch result {
        case .success(let response):
            onSucced(response, target: target, isFromError: false)
        case .failure(let error):
            onFail(error, target: target)
        }
    }
    
    private func onSucced(_ response: Response, target: TargetType, isFromError: Bool) {
        let request = response.request
        let statusCode = response.statusCode
        print("""
        ===============================================================
        - 🛰️ [RESPONSE] >>
        - [URL]:  \(request?.url?.absoluteString ?? "__none__")
        - [TIME]: \(Date().debugDescription)
        - [HEADER]: \(response.response?.allHeaderFields ?? [:])
        - [STATUSCODE]: \(statusCode)
        - [BODY]: \(response.data.prettyPrintedJSONString ?? "__none__")
        ===============================================================
        """)
    }
    
    private func onFail(_ error: MoyaError, target: TargetType) {
        if let response = error.response {
            onSucced(response, target: target, isFromError: true)
            return
        }
        
        print("""
        ===============================================================
        - !!! [REQUEST FAIL] !!!
        - [RESPONSE TIME]: \(Date().debugDescription)
        - [ERROR CODE]:  \(error.errorCode)
        - [ERROR STATUS CODE]:  \(error.response?.statusCode ?? -1)
        - [ERROR DESCRIPTION]: \(error.failureReason ?? error.errorDescription ?? "unknown error")
        ===============================================================
        """)
    }
}

private extension Data {
    var prettyPrintedJSONString: NSString? {
        guard let object = try? JSONSerialization.jsonObject(with: self, options: []),
              let data = try? JSONSerialization.data(withJSONObject: object, options: [.prettyPrinted]),
              let prettyPrintedString = NSString(data: data, encoding: String.Encoding.utf8.rawValue) else { return nil }
        
        return prettyPrintedString
    }
}
