//
//  NetworkCheckManager.swift
//  YBTour
//
//  Created by FOCUSONE Inc. on 2023/12/07.
//

import Foundation
import Network


/**
 * 네트워크 상태에 대한 매니저 클래스 입니다
 * `isConnected` 변수값을 이용해 네트워크가 연결되어있는지 확인 할 수 있습니다.
 */
final class MoyaNWPathMonitor {
    static let shared = MoyaNWPathMonitor()

    private let monitor: NWPathMonitor
    private let queue = DispatchQueue.global()
    private(set) var isConnected = false /// 네트워크 연결 여부
    private init() {
        monitor = NWPathMonitor()
    }
}

extension MoyaNWPathMonitor {
    func startMonitoring() {
        monitor.start(queue: queue)
        monitor.pathUpdateHandler = { [weak self] path in
            self?.isConnected = path.status == .satisfied
            NotificationCenter.default.post(name: .networkStateChanged, object: nil)
        }
    }
    func stopMonitoring() {
        monitor.cancel()
    }
}
