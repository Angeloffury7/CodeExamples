//
//  Constant.swift
//  YBTour
//
//  Created by FOCUSONE Inc. on 2023/11/10.
//

import Foundation


struct MoyaConstant {
    enum ServerType: Int {
        case dev = 1  /// 개발서버
        case br1      /// MBR1 스테이징 서버(1~4)
        case br2
        case br3
        case br4
        case prod     /// 운영서버

        /// 서버이름
        var serverName: String {
            switch self {
            case .dev:      return "DEV"
            case .br1:      return "BR1"
            case .br2:      return "BR2"
            case .br3:      return "BR3"
            case .br4:      return "BR4"
            case .prod:     return ""
            }
        }
        
        /// 디폴트 페이지 URL
        var serverURL: String {
            switch self {
            case .dev:      return "https://mdev.ybtour.co.kr"
            case .br1:      return "https://mbr1.ybtour.co.kr"
            case .br2:      return "https://mbr2.ybtour.co.kr"
            case .br3:      return "https://mbr3.ybtour.co.kr"
            case .br4:      return "https://mbr4.ybtour.co.kr"
            case .prod:     return "https://m.ybtour.co.kr"
            }
        }
        
        /// ybtour WWW가 포함된 URL
        var serverURLinWWW: String {
            switch self {
            case .dev:      return "https://dev.ybtour.co.kr"
            case .br1:      return "https://br1.ybtour.co.kr"
            case .br2:      return "https://br2.ybtour.co.kr"
            case .br3:      return "https://br3.ybtour.co.kr"
            case .br4:      return "https://br4.ybtour.co.kr"
            case .prod:     return "https://www.ybtour.co.kr"
            }
        }
        
        /// 인증관련 서버 URL
        var loginServerURL: String {
            switch self {
            case .dev:                        return "https://account-dev.ybtour.co.kr"
            case .br1, .br2, .br3, .br4:      return "https://account-dev.ybtour.co.kr"
            case .prod:                       return "https://account.ybtour.co.kr"
            }
        }
        
        /// OTA 서버 URL
        var otaServerURL: String {
            switch self {
            case .dev:                        return "https://dev-mota.ybtour.co.kr"
            case .br1, .br2, .br3, .br4:      return "https://dev-mota.ybtour.co.kr"
            case .prod:                       return "https://mota.ybtour.co.kr"
            }
        }
        
        /// 로그 서버 URL
        var otaLOGServerURL: String {
            switch self {
            case .dev:                        return "https://test-anacol.ybtour.co.kr:10443"
            case .br1, .br2, .br3, .br4:      return "https://test-anacol.ybtour.co.kr:10443"
            case .prod:                       return "https://anacol.ybtour.co.kr"
            }
        }
    }

    #if DEBUG
    static var serverType: ServerType! = .dev   /// 서버타입
    static let isDebug = true                   /// 디버그 여부
    #else
    static var serverType: ServerType! = .prod
    static let isDebug = false
    #endif
    
    static let serverName = serverType.serverName
    static var serverURL = serverType.serverURL
    static let serverURLinWWW = serverType.serverURLinWWW
    static let loginServerURL = serverType.loginServerURL
    static let otaServerURL = serverType.otaServerURL
    static let otaLOGServerURL = serverType.otaLOGServerURL
    static let otaLOGServerPath = "\(otaLOGServerURL)/nlog/log/event?v=600685015&s=ota_app&u="
    /// 패키지 여행 홈
    static var mainURL = "\(serverURL)/"
    /// 자유여행 홈
    static var otaMainURL = "\(otaServerURL)/"
    /// 결제 페이지 도메인
    static let ISPWebDomainURL = "http://sp.easypay.co.kr"
    /// 앱스토어 URL
    static let appStoreURL = "https://apps.apple.com/app/id1051602228"

    struct System {}
    struct Braze {}
    struct Kakao {}
    struct Naver {}
    struct AppGuard {}
    struct WebView {}
}

/// 시스템 설정 정보
extension MoyaConstant.System {
    static let bundleIdentifier = Bundle.main.infoDictionary?["CFBundleIdentifier"] as? String
    static let appVersion = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String
    static let buildVersion = Bundle.main.infoDictionary?["CFBundleVersion"] as? String
    /// notification 앱 그룹 아이디 정보
    static let notificationAppGroupID = "group.kr.co.ybtour.mobile.notification"
}

/// Braze 설정 정보
extension MoyaConstant.Braze {
    #if DEBUG ///Dev
    static let apiKey = "20ea5ee7-f4e4-467e-bb64-4b57db0c9dd0"
    #else ///Prod
    static let apiKey = "896ba4d0-be0d-4c15-8d8e-633fa34f9214"
    #endif
    
    static let endPoint = "sdk.iad-05.braze.com"
    @frozen
    enum BrazeType: String {
        case event = "event"
        case purchase = "purchase"
        case attribute = "attribute"
    }
}

/// Kakao 설정 정보
extension MoyaConstant.Kakao {
    #if DEBUG ///Dev
    static let apiKey = "675d7170e12c05e249a13ea172489a8b"
    #else ///Prod(키값 구분 될 경우 변경 요망)
    static let apiKey = "f0116a0ebaf40a658fe2a8149a4853f0"
    #endif
}

/// Naver 설정 정보
extension MoyaConstant.Naver {
    static let serviceUrlScheme = "ybtour"
    #if DEBUG ///Dev
    static let consumerKey = "6zf5i8vuLz7CrXnreQOR"
    static let consumerSecret = "9azrUsJ2Zx"
    static let appName = "노랑풍선"
    #else ///Prod(키값 구분 될 경우 변경 요망)
    static let consumerKey = "XO_i3Vakaf718TVTR1hc"
    static let consumerSecret = "tSczvsyzY3"
    static let appName = "노랑풍선"
    #endif
}

/// AppGuard 설정 정보
extension MoyaConstant.AppGuard {
    static let appkey = "iSAy2VfwyMDIp1DQ" 
    static let userID = "ybtour.co.kr@gmail.com"
    static let appname = "kr.co.ybtour.mobile"
}

/// WebView
extension MoyaConstant.WebView {
    /// 홈 하단 버튼 정보
    enum ButtonType: Int {
        case home = 0
        case goBack
        case search
        case push
        case setting
    }
    
    /// webPage 메시지 핸들러 이름
    enum HandlerName {
        static let log = "log"
        static let braze = "BrazeCallbackHandler"
    }
    
    /// webPage에 대한 스키마 처리 액션 enum
    enum WebAction: String {
        case confirmCamera = "confirmCamera"                                    /// 카메라 권한
        case confirmPhotoLibrary = "confirmPhotoLibrary"                        /// 앨범 권한
        case confirmCameraAndPhotoLibrary = "confirmCameraAndPhotoLibrary"      /// 카메라, 앨범 권한
        case openBrowser = "openBrowser"                                        /// 새창으로 열기
        case openURLShare = "openUrlShare"                                      /// 공유하기
        case urlCopy = "urlCopy"                                                /// URL 복사
        case openSettingView = "openSettingView"                                /// 설정화면 이동
        case openPushlistView = "openPushlistView"                              /// 알림리스트 화면 이동
        case setPullToRefresh = "setPullToRefresh"                              /// 당겨서 새로고침 여부
        case setDebugMode = "setDebugMode"                                      /// 디버그 모드 여부
        case pushFbAEventLog = "pushFbAEventLog"                                /// 파이어베이스 애널리틱스 로그 전송
        case openSignInView = "openSignInView"                                  /// 네이티브 로그인 화면
        case setNavigationBar = "setNavigationBar"                              /// 하단 툴바 show/hidden처리 여부
    }
    
    enum PushHostAction: String {
        case ispAuthorizationComplete                                           /// isp
        case application                                                        /// 일반적인 push
        case ota                                                                /// 결제 완료 리다이렉트
    }
    
    // 다이나믹 링크 네이티브 스크린 이동 명
    enum DynamicLinkScreen: String {
        case settings = "settings"                                              /// 설정 페이지 이동
    }
    
    /// 앱 미 설치시 이동할 앱스키마 명
    enum AppScheme: String {
        case kakaotalk = "kakaotalk"                                            /// 카카오톡
        case kakaolink = "kakaolink"
        case kakaoplus = "kakaoplus"
        case kakaobizchat = "kakaobizchat"
        case kbacp = "kb-acp"                                                   /// 뱅크페이
        case kbbank = "kbbank"                                                  /// kbbank
        case ispmobile = "ispmobile"                                            /// isp페이북
        case toss = "supertoss"                                                 /// toss
    }
}
