//
//  Notification.Name+.swift
//  YBTour
//
//  Created by FOCUSONE Inc. on 2023/12/04.
//

import Foundation


extension Notification.Name {
    static let removeCache = Notification.Name("removeCache")                               // 캐시 삭제
    static let removeMember = Notification.Name("removeMember")                             // 계정 삭제
    static let requestFindPushAgreeInfo = Notification.Name("requestFindPushAgreeInfo")     // 푸시 정보 가져오기
    static let loginStateChanged = Notification.Name("loginStateChanged")                   // 로그인 상태 변경
    static let quickActionReserv = Notification.Name("quickActionReserv")                   // 퀵 액션
    static let networkStateChanged = Notification.Name("networkStateChanged")               // 네트워크 상태 변화
}
