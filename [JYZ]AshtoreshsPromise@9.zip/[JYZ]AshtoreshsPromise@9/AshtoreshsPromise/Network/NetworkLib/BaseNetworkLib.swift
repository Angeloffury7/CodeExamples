//
//  BaseNetworkLib.swift
//  AshtoreshsLibrary
//
//  Created by YBTourDev on 5/14/24.
//  Copyright © 2024 이동건. All rights reserved.
//

import Foundation
import Alamofire
import Moya
import Combine


//MARK: - AFNetworkError
enum BaseAFNetworkError: Error {
    case invalidURL
    case requestFailed
    case signupFailed
    case responseParsingFailed
    case authenticationError
}
//MARK: - BaseResponseREST
struct BaseResponseREST<T: Decodable>: Decodable {
    var code: String?
    var data: T?
    var message: String?
    var timestamp: String?
    
    enum CodingKeys: String, CodingKey {
        case code = "code"
        case message = "message"
        case data = "body"
        case timestamp = "timestamp"
    }
}


//MARK: - BaseAFNetworkLib
class BaseNetworkLib {
    //MARK: Singleton
    public static let sharedManager = BaseNetworkLib()
    
    //MARK: MoyaLib
    private let MoyaRequestCloser: MoyaProvider<RESTAPITarget>.RequestClosure = { 
        endpoint, done in
        do {
            var request = try endpoint.urlRequest()
            request.timeoutInterval = 30
            done(.success(request))
        } catch {
            done(.failure(MoyaError.underlying(error, nil)))
        }
    }
    private lazy var moyaProvider = MoyaProvider<RESTAPITarget>(requestClosure: MoyaRequestCloser,
                                                                session: Session(interceptor: KeyReqInterceptor()),
                                                                plugins: [MoyaLoggingPlugIn()])
}
private extension BaseNetworkLib {
    public func errorHandling(statusCode: Int,
                              errorMessage: String = "") -> MoyaAPIError {
        switch statusCode {
        case 400..<500:
            return MoyaAPIError.requestError
        case 500:
            return MoyaAPIError.serverError
        default:
            return MoyaAPIError.unknown(message: errorMessage)
        }
    }
}


//MARK: - URLSession(DefaultURLSession)
extension BaseNetworkLib {
    public static func baseURLSession<T:Codable>(with urlString:String?,
                                                 method:HTTPMethod? = .get,
                                                 parametersData: [String:Any]? = nil,
                                                 headerData: HTTPHeaders? = nil,
                                                 of typeSelf: T.Type = T.self,
                                                 completion: @escaping (Result<T, Error>) -> ()) {
        ///dataTask(Swift)
        URLSession.shared.dataTask(with: URL(string: urlString!)!) { data, _, _ in
            guard let data = data else { return }
            guard let decodingData = try? JSONDecoder().decode(typeSelf, from: data) else { return }
            completion(Result.success(decodingData))
        }.resume()
        /**
         ///dataTaskPublisher(Combine)
         URLSession.shared.dataTaskPublisher(for: request)
         .tryMap { result -> HTTPResponse<T> in
         let value = try self.decoder.decode(T.self, from: result.data)
         return HTTPResponse(value: value, response: result.response)
         }
         .receive(on: DispatchQueue.main)
         .eraseToAnyPublisher()
         */
    }
}


//MARK: - AlamofireLib
extension BaseNetworkLib {
    public static func baseAFCompletion<T:Codable>(with urlString:String,
                                                   method:HTTPMethod? = .get,
                                                   parametersData: [String:Any]? = nil,
                                                   headerData: HTTPHeaders? = nil,
                                                   completion: ((Result<T,Error>) -> ())? )  {
        AF.session.request(urlString,
                           method: method!,
                           parameters: parametersData,
                           encoding: URLEncoding.default,
                           headers: headerData,
                           interceptor: KeyReqInterceptor() as RequestInterceptor)
        .validate(statusCode:200..<410)
        .response(completionHandler:{ response in
            switch response.result {
            case .success(let data):
                do {
                    completion?(.success(try ((JSONDecoder().decode(T.self, from: data!) as? T)!)))
                } catch(_){
                }
                break
            case .failure(_):
                break
            }
        })
    }
    public static func baseAFCombine<T:Codable>(with urlString:String,
                                                method:HTTPMethod? = .get,
                                                parametersData: [String:Any]? = nil,
                                                headerData: HTTPHeaders? = nil) -> AnyPublisher<T, Error>  {
        AF.session.request(urlString,
                           method: method!,
                           parameters: parametersData,
                           encoding: URLEncoding.default,
                           headers: headerData,
                           interceptor: KeyReqInterceptor() as RequestInterceptor)
        .validate(statusCode:200..<410)
        .publishDecodable(type: T.self)
        .tryMap { response in
            return response.data as! T
        }
        .mapError { error in ///내부 Publisher에서 발생한 에러를 다른 에러 타입으로 변환
            if error is BaseAFNetworkError {
                return BaseAFNetworkError.signupFailed
            } else {
                return error as! BaseAFNetworkError
            }
        }
        .receive(on: DispatchQueue.main)
        .eraseToAnyPublisher()
    }
    public static func baseAFPromise<T:Codable>(with urlString:String,
                                                method:HTTPMethod? = .get,
                                                parametersData: [String:Any]? = nil,
                                                headerData: HTTPHeaders? = nil) -> Future<T, Error> {
        return Future<T, Error> { promise in
            AF.session.request(urlString,
                               method: method!,
                               parameters: parametersData,
                               encoding: URLEncoding.default,
                               headers: headerData,
                               interceptor: KeyReqInterceptor() as RequestInterceptor)
            .validate(statusCode:200..<410)
            .response(completionHandler:{ response in
                switch response.result {
                case .success(let data):
                    do {
                        promise(.success(try (JSONDecoder().decode(T.self, from: data!) as? T)!))
                    } catch(_){
                    }
                    break
                case .failure(_):
                    break
                }
            })
        }
    }
}


//MARK: - MoyaLib
extension BaseNetworkLib {
    @discardableResult
    public func baseMoyaCountination<T: Decodable>(to target: RESTAPITarget,
                                                   resultType: T.Type,
                                                   errorPopup: Bool = true) async throws -> (HTTPURLResponse?, T) {
        return try await withCheckedThrowingContinuation { countination in
            guard MoyaNWPathMonitor.shared.isConnected else {
                countination.resume(throwing: MoyaAPIError.networkError)
                return
            }
            MoyaProvider<RESTAPITarget>(requestClosure: MoyaRequestCloser,
                                        session: Session(interceptor: KeyReqInterceptor()),
                                        plugins: [MoyaLoggingPlugIn()]).request(target) { result in
                switch result {
                case .success(let response):
                    guard let decodeData = try? response.map(T.self) else {
                        _Concurrency.Task {
                            await MainActor.run {
                                return countination.resume(throwing: MoyaAPIError.decodeError)
                            }
                        }
                        return
                    }
                    return countination.resume(returning: (response.response, decodeData))
                case .failure(let error):
                    _Concurrency.Task {
                        await MainActor.run {
                            UIAlertController.alert(
                                UIApplication.shared.rootViewController,
                                title: "",
                                message: "There is a problem connecting to the network. Please try again in a few minutes."
                            ) { [weak self] _ in
                                guard let self = self else { return }
                                guard let statusCode = error.response?.statusCode else {
                                    return countination.resume(throwing: MoyaAPIError.unknown(message: error.localizedDescription))
                                }
                                return countination.resume(throwing: self.errorHandling(statusCode: statusCode))
                            }
                        }
                    }
                }
            }
        }
    }
}
