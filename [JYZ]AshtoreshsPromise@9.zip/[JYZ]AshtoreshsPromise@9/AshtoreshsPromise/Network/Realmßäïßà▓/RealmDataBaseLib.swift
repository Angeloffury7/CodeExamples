//
//  RealmDataBaseLib.swift
//  AshtoreshsPromise
//
//  Created by YBTourDev on 5/24/24.
//  Copyright © 2024 이동건. All rights reserved.
//

import UIKit
import RealmSwift


//MARK: - RealmDataBase(Protocol: https://ios-daniel-yang.tistory.com/7)
protocol BaseRealmProtocol {
    func read<T: Object>(_ object: T.Type) -> Results<T>
    func write<T: Object>(_ object: T)
    func delete<T: Object>(_ object: T)
    func sort<T: Object>(_ object: T.Type, by keyPath: String, ascending: Bool) -> Results<T>
}


//MARK: - RealmDataBase(Class)
final class RealmDataBaseLib: BaseRealmProtocol, ObservableObject {
    //MARK: Variable
    static public let sharedManager = RealmDataBaseLib()
    public let database: Realm
    //MARK: Initialize
    private init() {
        self.database = try! Realm()
    }
}


//MARK: - RealmDataBase(Initialize)
extension RealmDataBaseLib {
    public func getLocationOfDefaultRealm() {
        print("Realm is located at:", database.configuration.fileURL!)
    }
}


//MARK: - RealmDataBase(CRUD)
extension RealmDataBaseLib {
    public func read<T: Object>(_ object: T.Type) -> Results<T> {
        return self.database.objects(object)
    }
    public func write<T: Object>(_ object: T) {
        do {
            try self.database.write {
                self.database.add(object, update: .modified)
                print("New Item")
            }
        } catch let error {
            print(error)
        }
    }
    public func update<T: Object>(_ object: T, completion: @escaping ((T) -> ())) {
        do {
            try self.database.write {
                completion(object)
            }
        } catch let error {
            print(error)
        }
    }
    public func delete<T: Object>(_ object: T) {
        do {
            try self.database.write {
                self.database.delete(object)
                print("Delete Success")
            }
        } catch let error {
            print(error)
        }
    }
    public func sort<T: Object>(_ object: T.Type, by keyPath: String, ascending: Bool = true) -> Results<T> {
        return database.objects(object).sorted(byKeyPath: keyPath,
                                               ascending: ascending)
    }
}
