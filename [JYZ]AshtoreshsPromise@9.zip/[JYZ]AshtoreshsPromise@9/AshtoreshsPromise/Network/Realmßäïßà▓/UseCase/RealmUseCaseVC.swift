//
//  RealmUseCaseVC.swift
//  AshtoreshsPromise
//
//  Created by YBTourDev on 5/24/24.
//  Copyright © 2024 이동건. All rights reserved.
//

import Foundation
import UIKit
import RealmSwift
import CoreLocation



//MARK: - RealmUseCaseVC(VC)
class RealmUseCaseVC: UIViewController {
    ///로컬영역에서 사용기하기 위해 실행
    ///이미 AppDelegate에서 실행시켰으므로 로컬영역에서는 try!로 간단히 사용
    public let realm = try! Realm()
    ///데이터를 읽을 수 있게 Realm의 Results 타입으로 만들어주자
    ///⭐️ Results는 자동업데이트 컨테이너이다 (속성이 변할 때 마다 append를 자동으로 수행.)
    public var categorys: Results<Category>?
}


//MARK: - RealmUseCaseVC(CRUD)
extension RealmUseCaseVC {
    ///Create (모델을 담는다)
    public func saveCategorys(category: Category) {
        do {
            try realm.write({
                realm.add(category)
            })
        } catch {
            print("Error save: \(error)")
        }
    }
    ///Read
    public func loadCategorys() {
        // 단 한줄이면 되는데 오른손의 타입이 Results<Category> 타입인걸 명심하자
        categorys = realm.objects(Category.self)
    }
    ///Update 동작은 Create와 같다
    public func updateItem(completion: () -> Void) {
        do {
            try realm.write {
                completion()
            }
        } catch {
            print("Error save: \(error)")
        }
    }
}


//MARK: - RealmUseCaseVC(Configure)
extension RealmUseCaseVC {
    public func realmConfigure() {
        ///싱글톤 객체 가져오기
        let database = RealmDataBaseLib.sharedManager
        ///Realm 파일 위치 가져오기
        database.getLocationOfDefaultRealm()
        /**
        //MARK: CRUD
        ///Create
        let task = Shopping(title: inputTextField.text!, createdAt: Date())
        database.write(task)
        ///Read
        shoppingList = database.read(Shopping.self)
        ///Update
        let model = RealmManager.shared.read(RealmDataModel.self)[indexPath.row]
        RealmManager.shared.update(model) { model in
            model.mainLoad = true
        }
        ///Sort
        tasks = database.sort(Shopping.self, by: "title")
        ///Delete
        database.delete(self.shoppingList[indexPath.row])
         */
    }
}


//MARK: - RealmUseCaseVC(DispatchQueue)
extension RealmUseCaseVC {
    public func RealmUseCaseDispatchQueue() {
        DispatchQueue.main.async {
            ///self.read(RealmDataModel.self).forEach { model in
            RealmDataBaseLib.sharedManager.read(RealmBaseModel.self).forEach { model in
                if model.loadMain == true {
                    Task {
                        ///await WeatherManager.shared.eachWeatherData(lat: model.lat, lon: model.lon)
                    }
                }
            }
        }
    }
    public func RealmUseCaseAsyncStream() {
        var list: [CLLocation] = []
        ///let weatherData = RealmManager.shared.sort(RealmDataModel.self, by: "date")
        let weatherData = RealmDataBaseLib.sharedManager.sort(RealmBaseModel.self, by: "date")
        weatherData.forEach { result in
            ///list.append(CLLocation(latitude: result.lat, longitude: result.lon))
        }
        let data = AsyncStream<CLLocation> { continuation in
            for location in list {
                continuation.yield(location)
            }
            continuation.finish()
        }
        Task {
            for await location in data {
                let coordinate = location.coordinate
                ///sawait self.eachWeatherData(lat: coordinate.latitude, lon: coordinate.longitude)
            }
        }
    }
}


//MARK: - RealmUseCaseVC(UITableView)
extension RealmUseCaseVC:UITableViewDelegate {
    public func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "goToItems", sender: self)
    }
    override public func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destivationVC = segue.destination as! RealmServiceCRUD
        /**
        if let indexPath = self.tableView.indexPathForSelectedRow {
            // 선택택 category의 인덱스로 불러오게 하여 selectCategory 속성을 트리거하게 만듬
            destivationVC.selectCategory = categorys?[indexPath.row]
        }*/
    }
}

