//
//  RealmBaseModel.swift
//  AshtoreshsPromise
//
//  Created by YBTourDev on 5/24/24.
//  Copyright © 2024 이동건. All rights reserved.
//

import Foundation
import RealmSwift


//MARK: - RealmBaseModel
class RealmBaseModel: Object {
    @objc dynamic var loadMain: Bool = false
}

//MARK: ReverseModel
class Item: Object {
    @objc dynamic var title: String = ""
    @objc dynamic var done: Bool = false
    ///역방향 릴레이션 설정 방법
    ///fromType: 정방향 모델의 메타타입으로 설정, property: 정방향 릴레이션에서 만들어준 배열 이름(items)
    var parentCategory = LinkingObjects(fromType: Category.self, property: "items")
}

//MARK: ForwardModel
///만들고 싶은 모델에 Object 채택, 그 후 Realm의 객체를 정의
class Category: Object {
    @objc dynamic var name: String = ""
    ///정방향 릴레이션 설정하는 방법 (배열을 만들어준다.)
    ///List는 Realm에서 일종의 배열이다 (ex. Array<Int> 배열의 타입 같다)
    let items = List<Item>()
}

