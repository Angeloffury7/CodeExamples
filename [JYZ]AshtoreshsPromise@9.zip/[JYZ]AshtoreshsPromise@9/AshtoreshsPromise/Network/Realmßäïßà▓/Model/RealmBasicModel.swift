//
//  RealmBasicModel.swift
//  AshtoreshsPromise
//
//  Created by YBTourDev on 5/24/24.
//  Copyright © 2024 이동건. All rights reserved.
//

import Foundation
import RealmSwift

/**
//MARK: - YBTourBalloon(Model)
class RealmBasicModel {
    @Persisted(primaryKey: true) var _id: ObjectId
    @Persisted var seq: String
    @Persisted var title: String
    @Persisted var message: String
    @Persisted var deepLink: String
    @Persisted var type: String
    @Persisted var timestamp: String
    
    convenience init(seq:String,
                     title:String,
                     message: String,
                     deepLink: String,
                     type: String,
                     timestamp: String
    ) {
        self.seq = seq
        self.title = title
        self.message = message
        self.deepLink = deepLink
        self.type = type
        self.timestamp = timestamp
    }
}
*/
