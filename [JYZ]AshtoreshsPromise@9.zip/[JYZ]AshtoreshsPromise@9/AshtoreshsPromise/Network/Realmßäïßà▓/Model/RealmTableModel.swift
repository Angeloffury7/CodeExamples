//
//  RealmTableModel.swift
//  AshtoreshsPromise
//
//  Created by YBTourDev on 5/24/24.
//  Copyright © 2024 이동건. All rights reserved.
//

import Foundation
import RealmSwift

/**
//MARK: - RealmTableModel(URL: https://odinios.tistory.com/7)
class RealmTableModel {
    @Persisted(primaryKey: true) var _id: ObjectId 
    @Persisted var title: String
    @Persisted var discription: String
    
    convenience init(title: String, discription: String) {
        self.title = title
        self.discription = discription
    }
}
*/
