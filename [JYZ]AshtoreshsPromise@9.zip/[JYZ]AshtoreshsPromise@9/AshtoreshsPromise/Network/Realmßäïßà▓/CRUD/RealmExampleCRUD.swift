//
//  RealmExampleCRUD.swift
//  CRUD operation - RealmSwift
//
//  Created by Joey Slomowitz on 13/6/18.
//  Copyright © 2018 Joey Slomowitz. All rights reserved.
//

import Foundation
import RealmSwift
import UIKit


//MARK: - RealmExampleCRUD(Class)
class RealmExampleCRUD {
    //MARK: Singleton
    public static let sharedManager = RealmExampleCRUD()
    public var realm = try! Realm()
    private init() {}

    //MARK: Variables
    public var notificationToken = NotificationToken()
}


//MARK: - CRUD
extension RealmExampleCRUD {
    //MARK: Create
    func create<T: Object>(object: T) {
        do {
            try realm.write {
                realm.add(object)
            }
        } catch {
            post(error)
        }
    }
    //MARK: Read
    func read<T: Object>(object: T.Type) -> Results<T>!  {
        let realm = RealmExampleCRUD.sharedManager.realm
        let results = realm.objects(T.self)
        return results
    }
    //MARK: Update
    func update<T: Object>(object: T, with dictionary: [String: Any?]) {
        do {
            try realm.write {
                for (key, value) in dictionary {
                    object.setValue(value, forKey: key)
                }
            }
        } catch {
            post(error)
        }
    }
    //MARK: Delete
    func delete<T: Object>(_ object: T) {
        do {
            try realm.write {
                realm.delete(object)
            }
        } catch {
            post(error)
        }
    }
    //MARK: Append an object to a 'List' (which is actually an Array, but realm doesn't currently support Arrays)
    public func appendToList<T: Object>(list: List<T>?, with items: [T]) {
        let realm = try! Realm()
        do {
            try! realm.write {
                list?.append(objectsIn: items)
            }
        }
    }
}


//MARK: - Perform a function straight after observing a change in Realm
extension RealmExampleCRUD {
    //MARK: Obsverver
    public func changesObserved(completion: @escaping () -> ())   {
        self.notificationToken = self.realm.observe { (notification, realm) in
            completion()
        }
    }
    public func stopObservingChanges() {
        self.notificationToken.invalidate()
    }
    //MARK: Check for a specific object with primary key
    public func objectExists(withPrimaryKey primaryKey: Int) -> Bool {
        return realm.object(ofType: RealmBaseModel.self, forPrimaryKey: primaryKey) != nil
    }
}


//MARK: - Error handling
extension RealmExampleCRUD {
    enum ErrorNotification {
        static let realmError = Notification.Name("RealmError")
    }
    func post(_ error: Error) {
        NotificationCenter.default.post(name: ErrorNotification.realmError, object: error)
    }
    func observeRealmError(in vc: UIViewController, completion: @escaping (Error?) -> Void) {
        NotificationCenter.default.addObserver(forName: ErrorNotification.realmError,
                                               object: nil,
                                               queue: nil) { (notification) in
                                                completion(notification.object as? Error)
        }
    }
    func stopObservingErrors(in vc: UIViewController) {
        NotificationCenter.default.removeObserver(vc, name: ErrorNotification.realmError, object: nil)
    }
}
