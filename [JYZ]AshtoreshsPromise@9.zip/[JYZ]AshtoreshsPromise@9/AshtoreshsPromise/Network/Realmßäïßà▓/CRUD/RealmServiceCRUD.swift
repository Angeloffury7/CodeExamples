//
//  ItemViewController.swift
//  AshtoreshsPromise
//
//  Created by YBTourDev on 5/24/24.
//  Copyright © 2024 이동건. All rights reserved.
//

import Foundation
import UIKit
import RealmSwift


class RealmServiceCRUD: UIViewController {
    
    public let realm = try! Realm()
    public var todoItems: Results<Item>?
    
    ///데이터 전달 받기위해
    public var selectCategory: Category? {
        didSet {
            self.loadItems()
        }
    }
    
    ///Create (⭐️ 릴레이션 관계에 있으므로 selectCategory.items에 접근해서 추가하는 방식으로 해야된다)
    public func saveItem(itmes: Item) {
        do {
            try self.realm.write({
                self.selectCategory?.items.append(itmes)
            })
        } catch {
            print("Error save: \(error)")
        }
    }
    
    ///Read
    public func loadItems() {
        ///category의 relationship인 itmes를 불러온다
        self.todoItems = self.selectCategory?.items.sorted(byKeyPath: "title",
                                                           ascending: true)
    }
    
    ///Update 동작은 Create와 같다
    public func updateItem(completion: () -> Void) {
        do {
            try self.realm.write {
                ///업데이트 조건
                completion()
            }
        } catch {
            print("Error update: \(error)")
        }
    }
    
    ///delete
    public func deleteItme(itme: Item) {
        do {
            try self.realm.write {
                self.realm.delete(itme)
            }
        } catch {
            print("Error delete: \(error)")
        }
    }
}
