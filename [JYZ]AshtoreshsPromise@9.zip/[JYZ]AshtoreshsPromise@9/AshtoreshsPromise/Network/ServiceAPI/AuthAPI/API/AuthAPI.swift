//
//  APIConnet.swift
//  TalkTalkNY
//
//  Created by HanilNW on 2023/07/20.
//

import Alamofire


class AuthAPI {
    static public func getProfile(completion:@escaping(Result<Profile, Error>)->()) {
        let stringURL = "\(authURL)/profile"
        AF.session.request(stringURL,
                   method: .get,
                   parameters: nil,
                   encoding: JSONEncoding.default,
                   headers: KeyChainToken.getAuthorizationHeader()!,
                   interceptor: (KeyReqInterceptor() as RequestInterceptor))
        .validate(statusCode:200..<410)
        .responseDecodable(of: Profile.self) { response in
            switch response.result{
            case .success(let data):
                completion(Result.success(data))
                break
            case .failure(let data):
                completion(Result.failure(data))
                break
            }
        }
    }
    
    static public func logout(completion:@escaping(Result<Int, Error>)->()) {
        ///http://112.217.204.155:9000/authz/logout
        let stringURL = "\(authURL)/authz/logout"
        let httpBodyParams = ["token": KeyChainToken.read("accessToken")]
        print("logout:\(stringURL)")
        AF.session.request(stringURL,
                   method: .delete,
                   parameters: httpBodyParams as Parameters,
                   encoding: JSONEncoding.default,
                   headers: KeyChainToken.getAuthorizationHeader()!,
                   interceptor: (KeyReqInterceptor() as RequestInterceptor))
        .validate(statusCode:200..<410)
        .response(completionHandler:{ response in
            switch response.result {
            case .success(_):
                completion(Result.success(((response.response!.statusCode))))
                break
            case .failure(_):
                break
            }
        })
    }
    
    static public func revoke(completion:@escaping(Result<Data, Error>)->()) {
        let stringURL = "\(authURL)/oauth2/revoke"
        let httpBodyParams = ["token": KeyChainToken.read("accessToken")!,
                              "token_type_hint": "refresh_token",
                              "client_id":"talk-talk-app",
                              "client_secret":client_secret]
        AF.session.request(stringURL,
                   method: .post,
                   parameters: httpBodyParams,
                   encoding: JSONEncoding.default,
                   interceptor: (KeyReqInterceptor() as RequestInterceptor))
        .validate(statusCode:200..<410)
        .response(completionHandler:{ response in
            switch response.result{
            case .success(let data):
                completion(Result.success(((data as Data?)!)))
            case .failure(let data):
                completion(Result.failure(data))
                return
            }
        })
    }
}
