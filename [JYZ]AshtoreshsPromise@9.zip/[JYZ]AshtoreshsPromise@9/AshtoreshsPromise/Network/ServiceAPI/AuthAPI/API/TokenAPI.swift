//
//  TokenAPI.swift
//  TalkTalkNY
//
//  Created by HanilNW on 2023/07/20.
//

import Alamofire


class TokenAPI {
    static public func tokenSwap(urlString:String, completion:@escaping(Result<TokenSwap, Error>, String) -> ()) {
        let code = urlString.codeSubString(subString: urlString)
        let stringURL = "\(authURL)/oauth2/token"
        let parametersData = ["client_id":"talk-talk-app",
                              "client_secret":client_secret,
                              "grant_type":"authorization_code",
                              "redirect_uri":"hyundai-talktalk://oauth2redirect",
                              "code": code]
        AF.session.request(stringURL,
                   method: .post,
                   parameters: parametersData,
                   encoding: URLEncoding.default,
                   headers: gHTTPHeaders,
                   interceptor: KeyReqInterceptor() as RequestInterceptor)
        .validate(statusCode:200..<410)
        .response(completionHandler:{ response in
            switch response.result{
            case .success(let data):
                do {
                    guard let decodingData = try JSONDecoder().decode(TokenSwap.self,from: data!) as TokenSwap? else {
                        return
                    }
                    completion(Result.success(decodingData), code)
                } catch(_) {
                }
            case .failure(let data):
                completion(Result.failure(data), "failure")
                break
            }
        })
    }
    
    static public func tokenRefresh(refreshToken:String,
                                    completion:@escaping(Result<TokenRefresh,Error>) -> ()) {
        let stringURL = "\(authURL)/oauth2/token"
        let httpBodyParams = ["refresh_token":refreshToken,
                              "grant_type":"refresh_token",
                              "client_id":"talk-talk-app",
                              "client_secret":client_secret]
        AF.session.request(stringURL,
                   method: .post,
                   parameters: httpBodyParams,
                   encoding: URLEncoding.default,
                   headers: gHTTPHeaders,
                   interceptor: KeyReqInterceptor() as RequestInterceptor)
        .validate(statusCode:200..<410)
        .response(completionHandler:{ response in
            switch response.result{
            case .success(let data):
                do {
                    guard let decodingData = try JSONDecoder().decode(TokenRefresh.self,from: data!) as TokenRefresh? else {
                        return
                    }
                    completion(Result.success(decodingData))
                } catch(_) {
                }
            case .failure(let data):
                completion(Result.failure(data.localizedDescription as! Error))
                break
            }
        })
    }
    
    static public func tokenConfirm(accessToken:String, completion:@escaping(Result<Data,Error>) -> ()) {
        let stringURL = "\(authURL)/oauth2/introspect"
        let httpBodyData = ["token":accessToken]
        AF.session.request(stringURL,
                   method: .post,
                   parameters: httpBodyData,
                   encoding: JSONEncoding.default,
                   headers: gHTTPHeaders,
                   interceptor: KeyReqInterceptor() as RequestInterceptor)
        .validate(statusCode:200..<410)
        .response(completionHandler:{ response in
            switch response.result{
            case .success(let data):
                completion(Result.success(data!))
            case .failure(let data):
                completion(Result.failure(data.localizedDescription as! Error))
                break
            }
        })
    }
    
    static public func pushToken(token:String, completion:@escaping(Result<String, Error>) -> ()) {
        let stringURL = "\(serverURL)/common/token"
        let parametersData = ["token":token]
        print("pushToken:\(stringURL),\n\(parametersData)")
        AF.session.request(stringURL,
                   method: .post,
                   parameters: parametersData,
                   encoding: URLEncoding.default,
                   headers: gHTTPHeaders,
                   interceptor: KeyReqInterceptor() as RequestInterceptor)
        .validate(statusCode:200..<410)
        .response(completionHandler:{ response in
            switch response.result{
            case .success(_):
                completion(Result.success(String(response.response!.statusCode)))
                break
            case .failure(_):
                break
            }
        })
    }
}

