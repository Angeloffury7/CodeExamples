//
//  TokenModel.swift
//  TalkTalkNY
//
//  Created by HanilNW on 2023/07/27.
//


//MARK: AcessToken
struct TokenSwap: Codable {
    let access_token: String?
    let refresh_token: String?
    let scope: String?
    let id_token: String?
    let token_type: String?
    let expires_in: Int
    
    private enum CodingKeys: String, CodingKey {
        case access_token = "access_token"
        case refresh_token = "refresh_token"
        case scope = "scope"
        case id_token = "id_token"
        case token_type = "token_type"
        case expires_in
    }
}




//MARK: ToeknRefresh
struct TokenRefresh: Codable {
    let access_token: String?
    let refresh_token: String?
    let scope: String?
    let id_token: String?
    let token_type: String?
    let expires_in: Int
    
    private enum CodingKeys: String, CodingKey {
        case access_token = "access_token"
        case refresh_token = "refresh_token"
        case scope = "scope"
        case id_token = "id_token"
        case token_type = "token_type"
        case expires_in
    }
}


//MARK: TokenConfirm
struct TokenConfirm: Codable {
    let active: Bool
    let sub: String?
    let aud: [String]?
    let nbf: Int
    let scope: String?
    let iss: String?
    let exp: Int
    let iat: Int
    let client_id: String?
    let token_type: String?
    
    enum CodingKeys: String, CodingKey {
        case active
        case sub
        case aud
        case nbf
        case scope
        case iss
        case exp
        case iat
        case client_id
        case token_type
    }
}


struct TokenConfirmTest: Codable {
    let active: Bool?
    enum CodingKeys: String, CodingKey {
        case active
    }
}

