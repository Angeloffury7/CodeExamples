//
//  AuthModel.swift
//  TalkTalkNY
//
//  Created by HanilNW on 2023/07/27.
//



//MARK: - Profile
struct Profile: Codable {
    let id: Int?
    let username: String?
    let name: String?
    let email: String?
    let mobile: String?
    let company: companyType
    let roles: [String]?
    
    struct companyType: Codable {
        let id: String?
        let name: String?
    }
    enum CodingKeys: String, CodingKey {
        case id
        case username = "username"
        case name = "name"
        case email = "email"
        case mobile = "mobile"
        case company
        case roles
    }
}


//MARK: - BaseData
protocol BaseData {
    var idx: Int { get }
    var title: String? { get }
    var contents: String? { get }
}
struct MainData:BaseData {
    var idx: Int
    var title: String?
    var contents: String?
}
let testMainData = MainData(idx: 0, title: "2", contents: "3")
