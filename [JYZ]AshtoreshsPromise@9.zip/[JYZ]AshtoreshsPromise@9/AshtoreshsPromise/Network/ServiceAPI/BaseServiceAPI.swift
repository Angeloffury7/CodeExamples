//
//  BaseServiceAPI.swift
//  AnnabelleSapphire
//
//  Created by YBTourDev on 5/14/24.
//  Copyright © 2024 이동건. All rights reserved.
//

import Foundation
import UIKit

//MARK: - Model
struct DateTimeModel {
    var currentDateTime: Date
}

//MARK: - BaseServiceAPI(Class)
class BaseServiceAPI {
    public static var currentModel = DateTimeModel(currentDateTime: Date())
}
extension BaseServiceAPI {
    //MARK: DateTimeService
    public static func CustomURLSessionService(onCompleted: @escaping (DateTimeModel) -> Void) {
        BaseRepogitory.URLSessionAPI { entity in
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd'T'HH:mm'Z'"

            guard let now = formatter.date(from: entity.currentDateTime) else { return }
            let model = DateTimeModel(currentDateTime: now)
            self.currentModel = model
            onCompleted(model)
        }
    }
    //MARK: CustomAlamofireService
    public static func CustomAlamofireService(onCompleted: @escaping (DateTimeModel) -> Void) {
        BaseRepogitory.AlamofireAPI { result in
            switch result {
            case .success(let entity):
                let formatter = DateFormatter()
                formatter.dateFormat = "yyyy-MM-dd'T'HH:mm'Z'"
                self.currentModel = DateTimeModel(currentDateTime: formatter.date(from: entity.currentDateTime)!)
                onCompleted(self.currentModel)
                break
            case .failure(_):
                break
            }
        }
    }
    //MARK: CustomAFCombineService
    public static func CustomAFCombineService(onCompleted: @escaping (DateTimeModel) -> Void) {
        BaseRepogitory.AFCombineAPI { result in
            switch result {
            case .success(let entity):
                let formatter = DateFormatter()
                formatter.dateFormat = "yyyy-MM-dd'T'HH:mm'Z'"
                self.currentModel = DateTimeModel(currentDateTime: formatter.date(from: entity)!)
                onCompleted(self.currentModel)
                break
            case .failure(_):
                break
            }
        }
    }
    //MARK: CustomMoyaCountinationService
    public static func CustomMoyaCountinationService(onCompleted: @escaping (DateTimeModel) -> Void) async {
        await BaseRepogitory.MoyaCountinationAPI { result in
            switch result {
            case .success(let entity):
                let formatter = DateFormatter()
                formatter.dateFormat = "yyyy-MM-dd'T'HH:mm'Z'"
                self.currentModel = DateTimeModel(currentDateTime: formatter.date(from: entity.currentDateTime)!)
                onCompleted(self.currentModel)
                break
            case .failure(_):
                break
            }
        }
    }
}
