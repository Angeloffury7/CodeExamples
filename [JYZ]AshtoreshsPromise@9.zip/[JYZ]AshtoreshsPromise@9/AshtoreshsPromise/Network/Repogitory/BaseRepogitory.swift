//
//  BaseRepogitory.swift
//  AnnabelleSapphire
//
//  Created by YBTourDev on 5/14/24.
//  Copyright © 2024 이동건. All rights reserved.
//

import Foundation
import UIKit
import WebKit
import Alamofire
import Moya
import Combine

    
class BaseRepogitory {
    //MARK: Singleton
    public static let sharedManager = BaseNetworkLib()
    //MARK: AnyCancellable
    private static var anyCancellable: Set<AnyCancellable> = []
    private static let provider = MoyaProvider<MoyaTargetType>()
}

//MARK: - URLSessionAPI
extension BaseRepogitory {
    public static func URLSessionAPI(urlString: String? = "",
                                     onCompleted: @escaping (UtcTimeModel) -> Void) {
        let url = "http://worldclockapi.com/api/json/utc/now"
        BaseNetworkLib.baseURLSession(with: url) {
            (result: Result<UtcTimeModel, Error>) -> () in
            switch result {
            case .success(let data):
                onCompleted(data)
                break
            case .failure(_):
                break
            }
        }
    }
}
//MARK: - AlamofireAPI
extension BaseRepogitory {
    public static func AlamofireAPI(urlString: String? = "",
                                    onCompleted: @escaping(Result<UtcTimeModel, Error>) -> ()) {
        let url = "http://worldclockapi.com/api/json/utc/now"
        BaseNetworkLib.baseAFCompletion(with: url) {
            (result: Result<UtcTimeModel, Error>) -> () in
            switch result {
            case .success(let data):
                onCompleted(Result.success(data))
                break
            case .failure(let error):
                onCompleted(Result.failure(error.localizedDescription as! Error))
                break
            }
        }
    }
    public static func AFCombineAPI(urlString: String? = "",
                                    onCompleted: @escaping(Result<String, Error>) -> ()) {
        ///let url = "https://jsonplaceholder.typicode.com/todos/1"
        let url = "http://worldclockapi.com/api/json/utc/now"
        BaseNetworkLib.baseAFCombine(with: urlString!)
            .decode(type: UtcTimeModel.self, decoder: JSONDecoder())
            .map { $0.currentDateTime }
            .handleEvents(receiveSubscription: { _ in print("Subscribed") },
                          receiveOutput: { _ in print("Received")},
                          receiveCompletion: { _ in print("Completed") },
                          receiveCancel: { print("Canceled") },
                          receiveRequest: {_ in print("Requested") })
            .sink(receiveCompletion: { completion  in
                print("AFCombineAPI_receiveCompletion:\(String(describing: completion))")
            },receiveValue: { value in
                print("AFCombineAPI_receiveValue:\(String(describing: value))")
                onCompleted(Result.success(value))
            })
            .store(in: &anyCancellable)
    }
}
//MARK: - MoyaCountinationAPI
extension BaseRepogitory {
    public static func MoyaCountinationAPI(urlString: String? = "",
                                           onCompleted: @escaping(Result<UtcTimeModel,Error>) -> ()) async {
        do {
            let (urlResponse, result) = try await BaseNetworkLib.sharedManager.baseMoyaCountination(to: .getUser,
                                                                                                    resultType: BaseResponseREST<UtcTimeModel>.self,
                                                                                                    errorPopup: false)
            guard let resultCode = result.code, resultCode.isEmpty else {
                return
            }
            guard let header = urlResponse?.allHeaderFields as? [String: String], let url = urlResponse?.url else {
                return
            }
            guard HTTPCookie.cookies(withResponseHeaderFields: header, for: url) != nil else {
                return
            }
            onCompleted(Result.success(result.data!))
        } catch let error as Error {
            onCompleted(Result.failure(error))
        }
    }
}
