//
//  AppDelegate.swift
//  CustomTabBar
//
//  Created by 이동건 on 2018. 4. 18..
//  Copyright © 2018년 이동건. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    static let GITHUB_API_REST = "https://api.github.com"
    var window: UIWindow?

    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        //MARK: Permission
        PermissionDelegate.registerRequestAuthorizationPopup()
        
        //MARK: Window
        self.window = UIWindow(frame:UIScreen.main.bounds)
        ///[TabBar]
        ///wireFrame.prensetRootViewController(rootViewController: rootViewController, window: window!)
        ///[RootViewController]
        self.window?.rootViewController = UINavigationController(rootViewController: CCollectionLibVC())
        self.window?.makeKeyAndVisible()
        return true
    }
    
    
    //MARK: UISceneSession Lifecycle
    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }
    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }
}

