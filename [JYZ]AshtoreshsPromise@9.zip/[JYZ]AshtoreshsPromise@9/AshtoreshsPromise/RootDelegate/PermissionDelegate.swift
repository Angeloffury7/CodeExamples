//
//  IDFADelegate.swift
//  YBTour
//
//  Created by YBTourDev on 5/20/24.
//

import Foundation
import AdSupport
import AppTrackingTransparency
import UserNotifications
///import BrazeKitCompat

//MARK: - PermissionDelegate(Class)
class PermissionDelegate: NSObject {}


//MARK: - PushNotification(AlertSetting)
//https://ios-development.tistory.com/1079
//https://velog.io/@doyun/UIkit-%EB%A1%9C%EC%BB%AC-%ED%91%B8%EC%89%AC-%EC%95%8C%EB%A6%BC-Local-Notification
extension PermissionDelegate {
    public static func registerRequestAuthorizationPopup () {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert,.badge,.sound]) { (didAllow,e) in }
    }
    public static func registerAuthorizationStatus() async -> Bool {
        return await UNUserNotificationCenter.current().notificationSettings().authorizationStatus == .authorized
    }
    public static func registerdgetNotificationSettings() {
        UNUserNotificationCenter.current().getNotificationSettings { settings in
            guard (settings.authorizationStatus == .authorized) ||
                  (settings.authorizationStatus == .provisional) else { return }
            if settings.alertSetting == .enabled {
                // Schedule an alert-only notification.
            } else {
                // Schedule a notification with a badge and sound.
            }
        }
    }
    public static func requestNotificationPermission(){
        UNUserNotificationCenter.current()
            .getNotificationSettings { permission in
                switch permission.authorizationStatus  {
                case .authorized:
                    print("푸시 수신 동의")
                case .denied:
                    print("푸시 수신 거부")
                case .notDetermined:
                    print("한 번 허용 누른 경우")
                case .provisional:
                    print("푸시 수신 임시 중단")
                case .ephemeral:
                    // @available(iOS 14.0, *)
                    print("푸시 설정이 App Clip에 대해서만 부분적으로 동의한 경우")
                @unknown default:
                    print("Unknow Status")
                }
            }
    }
}

//MARK: - IDFA
extension PermissionDelegate {
    //MARK: IDFA 값을 가져오는 함수
    public static func advertisingIdentifierString() -> String {
        return ASIdentifierManager.shared().advertisingIdentifier.uuidString
    }
    //MARK: 사용자가 제한된 광고 추적을 활성화 했는지 체크 함수
    public static func isAdvertisingTrackingEnabledOrATTAuthorized() -> Bool {
        if #available(iOS 14, *) {
            return ATTrackingManager.trackingAuthorizationStatus ==  ATTrackingManager.AuthorizationStatus.authorized
        }
        return ASIdentifierManager.shared().isAdvertisingTrackingEnabled
    }
    //MARK: 앱 추적 권한 팝업 함수
    public static func isAdvertisingTrackingPopup() { ///앱 추적 권한 요청
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.0, execute:{
            if #available(iOS 14, *) {
                ///앱 추적 권한 팝업 요청
                ATTrackingManager.requestTrackingAuthorization { (status) in
                    switch status {
                    case .authorized:///허용됨
                        print("[IDFA]: - [권한]/[허용됨]")
                        ///AppDelegate.braze?.set(adTrackingEnabled: true)
                        ///AppDelegate.braze?.set(identifierForAdvertiser: ASIdentifierManager.shared().advertisingIdentifier.uuidString)
                    case .denied:///거부됨
                        print("[IDFA]: - [권한]/[거부됨]")
                        ///AppDelegate.braze?.set(adTrackingEnabled: false)
                        ///AppDelegate.braze?.set(identifierForAdvertiser: ASIdentifierManager.shared().advertisingIdentifier.uuidString)
                    case .notDetermined:///결정되지 않음
                        print("[IDFA]: -[권한]/[결정되지 않음]")
                    case .restricted:///제한됨
                        print("[IDFA]: - [권한]/[제한됨]")
                    @unknown default:///알려지지 않음
                        print("[IDFA]: - [권한]/[알려지지 않음]")
                    }
                }
            } else {
                ///AppDelegate.braze?.set(adTrackingEnabled: ASIdentifierManager.shared().isAdvertisingTrackingEnabled)
                ///AppDelegate.braze?.set(identifierForAdvertiser: ASIdentifierManager.shared().advertisingIdentifier.uuidString)
            }
        })
    }
}
