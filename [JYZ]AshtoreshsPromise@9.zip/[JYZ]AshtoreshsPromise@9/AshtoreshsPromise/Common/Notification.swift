//
//  Notification.swift
//  TalkTalkNY
//
//  Created by HanilNW on 2023/09/11.
//

import Foundation


//MARK: - Notification(Name)
extension Notification.Name {
    static let state = Notification.Name("doItSomeThing")
    static let bottomSheetType = Notification.Name("bottomSheetType")
    static let bottomSheetState = Notification.Name("BottomSheetState")
    static let tabBarState = Notification.Name("tabBarState")
    static let popUpState = Notification.Name("popUpState")
    static let searchTabState = Notification.Name("searchTabState")
    static let customSwitchState = Notification.Name("customSwitchState")
    static let dataRefresh = Notification.Name("dataRefresh")
    static let ToastMessageState = Notification.Name("ToastMessageState")
    static let restaurantState = Notification.Name("restaurantState")
    static let mealState = Notification.Name("mealState")
    static let textState = Notification.Name("textState")
}


//MARK: - Notification(Key)
enum NotificationKey {
    case state
    case bottomSheetType
    case bottomSheetState
    case tabBarState
    case popUpState
    case searchTabState
    case customSwitchState
    case dataRefresh
    case ToastMessageState
    case restaurantState
    case masterKeyState
    case mealState
    case textState
}
