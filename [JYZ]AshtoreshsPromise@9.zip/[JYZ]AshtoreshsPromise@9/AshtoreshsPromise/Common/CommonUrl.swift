//
//  HTTPHeaders.swift
//  TalkTalkNY
//
//  Created by HanilNW on 2023/07/20.
//

import Alamofire

//MARK: - URL
public let gHTTPHeaders:HTTPHeaders = ["Content-Type": "application/x-www-form-urlencoded"]


//MARK: BaseURL
///"http://19.19.20.139:9000"
///"http://112.217.204.155:9000"
public let authURL = "http://112.217.204.155:9000"
///"http://19.19.20.139:8080"
///"http://112.217.204.155:8080"
public let serverURL = "http://112.217.204.155:8080"
public var baseURL = ""
public let client_secret = "secret"


//MARK: Link
public let acEarthlink = "https://hgfhmc-ny.com/m/"
public let bEarthlink = "https://pf.kakao.com/_GZxbMxj"
public let fwFnblink = "https://apps.apple.com/us/app/sw-f-b/id1668925971"


//MARK: APIType
private enum UrlType: String {
    case logout = "http://auth-server:9000/authz/logout"
    case revoke = "http://auth-server:9000/oauth2/revoke"
    case isAuth = "/auth/is_authenticated"
    case chatKeyword = "/api/chatbot/keyword"
}



