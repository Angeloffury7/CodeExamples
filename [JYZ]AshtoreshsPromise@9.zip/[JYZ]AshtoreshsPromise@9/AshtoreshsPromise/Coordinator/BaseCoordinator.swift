//
//  MainCoordinator.swift
//  ShuttleBus
//
//  Created by hanilM2 on 2023/03/02.
//

import Foundation
import UIKit


protocol BaseCoordinatorProtocol {
    var navController: UINavigationController {get set}
    func start()
}

class BaseCoordinator: BaseCoordinatorProtocol {
    public var navController: UINavigationController
    public init(_ nvc: UINavigationController = UINavigationController()) {
        self.navController = nvc
    }
}
extension BaseCoordinator {
    //MARK: back, goTo, move
    public func back() {
        self.navController.popViewController(animated: true)
    }
    public func goTo<T: UIViewController>(vc: T.Type) {
        let viewControllerStack = navController.viewControllers
        for viewController in viewControllerStack {
            if let page = viewController as? T {
                self.navController.popToViewController(page, animated: false)
                return
            }
        }
    }
    public func move(vc: String) {
        let vc = UIStoryboard(name: "Main", bundle: Bundle.main).instantiateViewController(withIdentifier: vc)
        self.navController.pushViewController(vc, animated: true)
    }
    //MARK: Intro, Login
    public func start() {
        let vc = TabViewController.instantiate()
        vc.coordinator = self
        self.navController.pushViewController(vc, animated: false)
    }
}
