//
//  ExtensionCoordinator.swift
//  AnnabelleSapphire
//
//  Created by YBTourDev on 5/14/24.
//  Copyright © 2024 이동건. All rights reserved.
//

import Foundation
import UIKit

//MARK: - MoveCoordinator(Class)
class MoveCoordinator:BaseCoordinator {
    public static let sharedManager = MoveCoordinator()
}

//MARK: - MoveCoordinator(NavigationVC)
extension MoveCoordinator {
    //MARK: exampleNVC
    public func exampleNVC(nvc: UIViewController) {
        let vc = TabViewController.instantiate()
        vc.coordinator = self
        nvc.navigationController!.pushViewController(vc, animated: true)
    }
    //MARK: UseCase
    public func exampleNVC() {
        let vc = TabViewController.instantiate()
        vc.coordinator = self
        self.navController.pushViewController(vc, animated: false)
    }
}
//MARK: - MoveCoordinator(ModalVC)
extension MoveCoordinator {
    //MARK: exampleMVC
    public func exampleMVC(for mvc: UIViewController) {
        let modal = TabViewController.instantiate()
        modal.modalPresentationStyle = .overFullScreen
        mvc.present(modal, animated: false)
    }
    //MARK: UseCase(TabView)
    public func editFriendMVC(for mvc: UIViewController) {
        let modal = TabViewController.instantiate()
        modal.modalPresentationStyle = .popover
        mvc.present(modal, animated: true)
    }
    public func emojiTableMVC(for mvc: UIViewController) {
        let modal = TabViewController.instantiate()
        modal.modalPresentationStyle = .overCurrentContext
        mvc.present(modal, animated: true)
    }
    //MARK: UseCase(TempVC)
    public func realmMVC(for mvc: UIViewController) {
        let modal = CustomRealmVC.instantiate()
        modal.modalPresentationStyle = .popover
        mvc.present(modal, animated: true)
    }
}
//MARK: - MoveCoordinator(PopUpVC)
extension MoveCoordinator {
    public func examplePopup(for mvc: UIViewController) {
        let popup = TabViewController.instantiate()
        popup.modalPresentationStyle = .overFullScreen
        mvc.present(popup, animated: false)
    }
    //MARK: UseCase
    public func exampleUseCasePopup(for mvc: UIViewController) {
    }
}
